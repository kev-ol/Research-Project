{
  sp.sSpecName = "spec-cee-06-noctrl";

  /* set data specification */
  sp.sDataFilePath = "../data/2008-cee/";
  sp.asExogDataFiles = {"../data/2008-world/world1"~EXT,"../data/2008-world/dummies"~EXT};

  sp.cARlags = 6;
  sp.asEndoNames = { "lnipsa", "lncpi", "r-mkt", "lneur" };
  sp.aExogWSel = {};

  decl aExogZSel = {"Constant",0,0};
  decl sSampleEnd = "-1(-1)";

  sp.aCountries = {};    // country specific settings: { "country filename", {variables Z}, "sample" }
  sp.aCountries |= {{"czech",aExogZSel,"1998(1) - "~sSampleEnd}};
  sp.aCountries |= {{"hungary",aExogZSel,"1995(4) - "~sSampleEnd}};
  sp.aCountries |= {{"poland",aExogZSel,"1995(6) - "~sSampleEnd}};
  sp.aCountries |= {{"slovenia",aExogZSel,"1997(5) - "~sSampleEnd}};

  /* set factorization */
  sp_fFact = FactSignmjqr23;
  sp.iShock = strfind(sp.asEndoNames,"r-mkt");
  
  /* set prior */
  sp.s = 0; sp.v = -1;

  sp.sLtype = "m1";
}  

  

