#include "packages/oxutils/oxutils.h"

#import "packages/mj/mj"
#import "packages/arrayutils/arr"

#import "packages/var/var"
#include "packages/var/varlags.ox"
#include "packages/var/varirfs.ox"
#include "packages/var/varroots.ox"
#include "packages/var/VAR_rats.ox"
#include "packages/var/drawirfs.ox"
#include "packages/var/idcholeski.ox"

#include "mcmcconv.ox"
#include "devrep.ox"
#include "mcresid.ox"
#include "sacrifice.ox"


// /* ****************************************************************
//    script-like function that does all the estimations, given:
//    options in struct opt
//    specification in struct sp
//    and variance factorizing function sp_fFact
// */
estimate(const opt, const sp, const sp_fFact)
{
  /* prepare the output directory and log */
  systemcall("mkdir out");
  fopen("out/info.txt","l");

  /* print out specification info */
  opt.Info();
  println("********** ",sp.sSpecName," ********");
  sp.Info();
  sp.Save("out/"~sp.sSpecName~".o");

  /* count some quantities */
  decl cC = sizeof(sp.aCountries);
  decl cY = sizeof(sp.asEndoNames);
  decl cYlags = sizeof(sp.asEndoNames)*sp.cARlags;
  decl cK = sizeof(sp.asEndoNames)*sp.cARlags + mj::SelLength(sp.aExogWSel);
  
  /* Load and setup data */
  decl vars = new array[cC], c;
  for (c=0;c<cC;c++)
    {
      vars[c] = new VAR();
      vars[c].SetEndoNames(sp.asEndoNames);
      vars[c].SetExogSel(sp.aExogWSel~sp.aCountries[c][1]);
      vars[c].SetSample(sp.aCountries[c][2]);
      vars[c].SetARlags(sp.cARlags);
      vars[c].LoadData({sp.sDataFilePath~mj::split(sp.aCountries[c][0],"-")[0]~EXT}~sp.asExogDataFiles,1);
      
      vars[c].PlotData();
      SaveDrawWindow("out/data-"~sp.aCountries[c][0]~".eps");
      CloseDrawWindow();
    }

  /* declare some quantities needed for all estimations */
  decl mtoplot;
  decl mDICreport = zeros(3,3);

  /* starting values for the Gibbs sampler later */
  decl amStarts = new array[cC];

  /* By unit */
  println("***** By unit (bu)");
  {
    for (c=0; c<cC; c++)
      {
        println(sp.aCountries[c][0]);
        decl mPostDraws, mChainInfo,mirf;
        VAR_rats(vars[c],opt.cDraws,&mChainInfo,&mPostDraws);        
        mDICreport[0][] += DevianceReport(vars[c],mPostDraws);
        //  varResidualReport(mPostDraws, "out/err-bu-"~sp.aCountries[c][0], vars[c], fFact, 1);
        
        /* starting values for Gibbs later */
        amStarts[c] = mPostDraws[ransubsample(opt.cChains-opt.cChainsPooled,opt.cDraws)][];

        /* irfs: */
        /* ->OLS */
        mtoplot = varirf(vars[c].mARrep(), sp_fFact(vars[c].mUtU()/vars[c].cT(),vars[c].mARrep()), opt.cMAlags);
        DrawIRFs(c*cY, {<>,<>,mtoplot}, sp.asEndoNames, -1, sp.iShock);
        /* ->posterior */      
        irfsdraws(vars[c],mPostDraws,sp_fFact,opt.cMAlags,&mirf);
        mtoplot = quantilec(mirf,opt.vQuant);
        DrawIRFs(c*cY, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]}, sp.asEndoNames, -1, sp.iShock,
                 "out/irf-bu-"~sp.aCountries[c][0]~"-");
      }
    DrawAdjust(ADJ_AREAMATRIX, cC, cY);
    SaveDrawWindow("out/irfs-bu.eps");
    CloseDrawWindow();
  }

  /* Pooled */
  println("\n***** Pooled (po)");
  {
    decl mBigY = <>, mBigX = <>, mBigZ = <>;
    decl aselZ = new array[cC]; // selectors for each country variables in big X
    for (c=0;c<cC;c++)
      {
        mBigY |= vars[c].mY();
        mBigX |= vars[c].mX()[][0:cK-1];
        aselZ[c] = cK + range(columns(mBigZ),columns(mBigZ)+columns(vars[c].mX()[][cK:])-1);
        mBigZ = diagcat(mBigZ,vars[c].mX()[][cK:]);        
      }
    decl mBigWZ = (columns(mBigX) > cYlags) ? (mBigX[][cYlags:]~mBigZ) : mBigZ; 
        
    decl oBigVAR = new VAR();
    oBigVAR.SetData(mBigY,mBigX[][0:cYlags-1],mBigWZ);
    
    decl mPostDraws;
    VAR_rats(oBigVAR,opt.cDraws,<>,&mPostDraws);
    mDICreport[1][] = DevianceReport(oBigVAR,mPostDraws);
    
    /* starting values for Gibbs later */
    /* this is a mess... */
    for (c=0;c<cC;c++)
      {
        decl mcand = mPostDraws[ransubsample(opt.cChainsPooled,opt.cDraws)][];
        decl mCoefs_d, mResVar_d;
        decl mstarts = zeros(opt.cChainsPooled,sizerc(vars[c].mB())+sizerc(vars[c].mUtU()));
        for (decl i=0;i<rows(mcand);i++)
          {
            [mCoefs_d, mResVar_d] = Arr::UnVec(mcand[i][],{oBigVAR.mB(),oBigVAR.mUtU()});
            mstarts[i][] = (vec(mCoefs_d[:cK-1][]|mCoefs_d[aselZ[c]][])|vec(mResVar_d))';
          }
        amStarts[c] |= mstarts;
      }
    
    /* irfs */
    decl mirf;
    irfsdraws(oBigVAR,mPostDraws,sp_fFact,opt.cMAlags,&mirf);
    mtoplot = quantilec(mirf, opt.vQuant);
    DrawIRFs(0, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]}, sp.asEndoNames, -1, sp.iShock,"out/irf-pool-");    
    SaveDrawWindow("out/irfs-po.eps");
    CloseDrawWindow();

    /* sacrifice ratio */
    ReportSacrifice(mirf,0,1,sp.iShock,cY,-1,"out/sacrifice-po");
  }
  
  // #include "estimate-p2.ox"
  
 
  /* Bayesian pooling */
  println("\n***** Hierarchical prior (hp)");
  if (1)
  {
    /* amLinv - array that stores *diagonals* of Lc arrayed like coefficients */
    decl amLinv = new array[cC];
    for (c=0;c<cC;c++)
      {
        if (sp.sLtype[0]=='i')
          {
            print("L: identity\n");     
            amLinv[c] = ones(cK,cY);
          }
        else if (sp.sLtype[0]=='m')
          {
            decl vsig2y, vsig2x, vsig2 = <>, mx, mxlags, mb, mdat = vars[c].mY()~vars[c].mX()[][0:cK-1];
            /* compute residuals from OLS univariate AR */
            for (decl k=0; k<columns(mdat); k++)
              {
                [mx,mxlags] = varlags(mdat[][k],sp.cARlags);
                mxlags = ones(rows(mxlags),1)~mxlags;
                olsc(mx,mxlags,&mb);
                vsig2 ~= varc(mx-mxlags*mb);
              }
            vsig2y = vsig2[0:cY-1];
            vsig2x = vsig2[cY:];
            /* now construct L inv */
            print("L: minnesota-like\n");
            amLinv[c] = vsig2x'*(vsig2y.^(-1)); // print(amLinv[c]);
          }
        else oxrunerror(sprint("unknown Ltype",sp.sLtype));
      }
    /* Lrowsel, Lcolsel - arrays that store coordinates of coefficients assigned to each lambda */
    decl Lrowsel, Lcolsel;
    if (sp.sLtype[1]=='1' || sizeof(sp.aExogWSel)==0)
      {
        Lrowsel = { range(0,cK-1) };
        Lcolsel = { range(0,cY-1) };
      }
    else if (sp.sLtype[1]=='2')
      {
        Lrowsel = { range(0,cYlags-1), range(cYlags,cK-1) };
        Lcolsel = { range(0,cY-1), range(0,cY-1) };
      }
    else oxrunerror(sprint("unknown Ltype",sp.sLtype[1]));

    decl amZtZinv = new array[cC], amZtZinvchol = new array[cC];
    for (c=0;c<cC;c++)
      {
        amZtZinv[c] = invertsym(vars[c].mXtX()[cK:][cK:]);
        amZtZinvchol[c] = choleski(amZtZinv[c]);
      }
        
    /* starting points */
    decl amCoefs = new array[cC], amResVar = new array[cC];
    decl mMeanCoefs, mMeanResVar;
    decl iChain = 1; // later loop over iChain

    for (c=0;c<cC;c++)
      {
        [amCoefs[c], amResVar[c]] = Arr::UnVec(amStarts[c][iChain][],{vars[c].mB(),vars[c].mUtU()});
      }
    /* MeanCoefs and MeanResVar get values from the first country */
    [mMeanCoefs, mMeanResVar] = Arr::UnVec(amStarts[0][iChain][],{vars[0].mB(),vars[0].mUtU()});
    // truncate country specific coefs and perturb
    // (to avoid problems in the pooled case):
    mMeanCoefs = 0.999*mMeanCoefs[0:cK-1][];

    decl vlambda = zeros(1,sizeof(Lrowsel));
    /* intermediate quantities for conditional posteriors */
    decl sqrdevb;
    decl ds, iv;
    decl amLambdainv = new array[cC];
    decl amResVarinv = new array[cC];
    decl mvar, mvarchol, part2, vcoefs1, mcoefs1, vcoefs2, mcoefs2, mvarinv;
    
    /* storage of results */
    decl amirf = new array[cC]; // country irfs
    decl amSumCoefs = new array[cC], amSumResVar = new array[cC]; // post.means of coefs
    decl amcres = new array[cC]; // classes for analysing residuals
    for (c=0;c<cC;c++)
      {
        amirf[c] = zeros(opt.cDraws,opt.cMAlags*cY^2);
        amSumCoefs[c] = zeros(vars[c].cX(),vars[c].cY());
        amSumResVar[c] = zeros(vars[c].cY(),vars[c].cY());
        amcres[c] = new MCResid();
        amcres[c].Initialize(vars[c].cT(),cY,opt.cDraws,1);
      }
    decl mChainInfo = zeros(opt.cDraws,2);
    decl mirf = zeros(opt.cDraws,opt.cMAlags*cY^2); // mean irfs
    decl vlam = zeros(opt.cDraws,sizeof(Lrowsel));
    decl vroots = zeros(opt.cDraws,1);
    
    decl merrors = zeros(1,2);
    
    /*************************/
    /* Gibbs sampling begins */ 
    decl actdraw, draw, iChainLength = opt.cBurnout + opt.cThin*opt.cDraws;
    println("ChainLength: ",iChainLength,"\n");
    fclose("l");
    infoinit(1000, 10);
    for (actdraw=0;actdraw<iChainLength;actdraw++)
      {         
        info(actdraw,iChainLength);
 
        /* draw lambda and amLambdainv*/
        if (0) // fixing lambda exogenously
          {
            vlambda = ones(1,sizeof(Lrowsel))*0.01;
          }
        else
          {
            // create sqrdevb
            sqrdevb = zeros(cK,cY);
            for (c=0;c<cC;c++)
              {
                sqrdevb += sqr(amCoefs[c][:cK-1][] - mMeanCoefs).*amLinv[c];
              }
            // draw all lambdas
            for (decl lam=0;lam<sizeof(Lrowsel); lam++)
              {
                ds = (sizeof(sp.s)>1 ? sp.s[lam] : sp.s) + sumr(sumc(sqrdevb[Lrowsel[lam]][Lcolsel[lam]]));
                iv = (sizeof(sp.v)>1 ? sp.v[lam] : sp.v) + cC*sizerc(Lrowsel[lam])*sizerc(Lcolsel[lam]);
                vlambda[lam] = ds/ranchi(1,1,iv);
              }  

          }
        /* compute amLambdainv with new lambdas */
        for (c=0;c<cC;c++)
          {
            amLambdainv[c] = zeros(rows(mMeanCoefs),columns(mMeanCoefs));
            for (decl lam=0; lam<sizeof(Lrowsel); lam++)
              {
                amLambdainv[c][Lrowsel[lam]][Lcolsel[lam]]
                  = (1/vlambda[lam])*amLinv[c][Lrowsel[lam]][Lcolsel[lam]];
              }
          }
        
        /* draw amResVar and amCoefs */
        for (c=0;c<cC;c++)
          {
            /* draw mResVar */
            mvar = vars[c].ResInner(amCoefs[c]);
            amResVar[c] = mj::RanIWishart( mj::Choleski(mvar), vars[c].cT() );
            amResVarinv[c] = invertsym(amResVar[c]);

            /* draw B */
            mvar = invertsym(amResVarinv[c]**vars[c].mXtX()[:cK-1][:cK-1] + diag(vec(amLambdainv[c])));
            if (mvar==0)
              {
                println("invertsym failed when drawing B, diagonalize mvar instead");
                mvar = diag((diagonal(amResVarinv[c]**vars[c].mXtX()[:cK-1][:cK-1]) +
                             vec(amLambdainv[c])').^(-1));
                merrors[0] += 1;
              }
            part2 = vec( 
                        (vars[c].mX()[][:cK-1])'(vars[c].mY() - vars[c].mX()[][cK:]*amCoefs[c][cK:][])*amResVarinv[c]
                        + amLambdainv[c].*mMeanCoefs );

            mvarchol = choleski(mvar);
            if (mvarchol==0)
              {
                println("choleski failed when drawing B, diagonalize mvar instead");
                mvarchol = diag(sqrt(diagonal(mvar)));
                merrors[1] += 1;
              }
            vcoefs1 = mvar*part2 + mvarchol*rann(rows(mvar),1);
            mcoefs1 = mj::Shape(vcoefs1,rows(mMeanCoefs),columns(mMeanCoefs));

            /* draw G */
            mvar = amResVar[c]**amZtZinv[c];
            part2 = vec(vars[c].mX()[][cK:]'*(vars[c].mY() - vars[c].mX()[][:cK-1]*mcoefs1)*amResVarinv[c]);
            vcoefs2 = mvar*part2 + (mj::Choleski(amResVar[c])**amZtZinvchol[c])*rann(rows(mvar),1);
            mcoefs2 = mj::Shape(vcoefs2,vars[c].cX() - cK,cY);

            amCoefs[c] = mcoefs1|mcoefs2;
            
          }

        /* draw mMeanCoefs */
        mvarinv = 0;
        part2 = 0;
        for (c=0;c<cC;c++)
          {
            mvarinv += amLambdainv[c];
            part2 += amLambdainv[c].*amCoefs[c][:cK-1][];
          }
        mvar = mvarinv.^(-1);
        mMeanCoefs = mvar.*part2 + sqrt(mvar).*rann(cK,cY);
        

        /**********************************************************/
        /* parameters drawn, now store the results of interest */
        
        if (actdraw>(opt.cBurnout-1) && imod(actdraw - opt.cBurnout + 1,opt.cThin)==0 )
          {
            draw = idiv(actdraw - opt.cBurnout + 1,opt.cThin)-1;
            
            mChainInfo[draw][0] = actdraw;
            for (c=0;c<cC;c++)
              {
                mChainInfo[draw][1] += vars[c].LogLikelihood(amCoefs[c],amResVar[c]);
              }
            
            vroots[draw][] = VARroots::MaxRoot(mMeanCoefs[:vars[0].cYlags()-1][]);
            
            /* lambda */
            vlam[draw][] = vlambda;

            /* country irfs */
            for (c=0;c<cC;c++)
              {
                amirf[c][draw][] = varirf(amCoefs[c][0:cYlags-1][],
                                           sp_fFact(amResVar[c],amCoefs[c][0:cYlags-1][]), opt.cMAlags);
              }        

            /* mean irf */
            decl mMeanResVar = zeros(cY,cY);
            decl cTotalT = 0;
            for (c=0;c<cC;c++)
              {
                mMeanResVar += amResVar[c]*vars[c].cT();
                cTotalT += vars[c].cT();
              }
            mirf[draw][] = varirf(mMeanCoefs[0:cYlags-1][],
                                   sp_fFact(mMeanResVar/cTotalT,mMeanCoefs[0:cYlags-1][]), opt.cMAlags);

            /* residuals */
            for (c=0;c<cC;c++)
              {
                decl mU = (vars[c].mY() - vars[c].mX()*amCoefs[c])*
                  invert(sp_fFact(amResVar[c],amCoefs[c][0:cYlags-1][])');
                amcres[c].StoreDraw(draw,mU);
              }
            
            /* mean coefficients and variances */
            for (c=0;c<cC;c++)
              {
                amSumCoefs[c] += amCoefs[c];
                amSumResVar[c] += amResVar[c];
              }
            
          } // storing results done

      } // Gibbs sampling done  
    :report_results
       fopen("out/info.txt","la");
    info(actdraw,iChainLength);
  
    /****************************/
    /* report posterior results */
    print("\n",actdraw+1," draws performed, ",draw+1," draws stored\n");    
    
    /* Deviance calculation and report */
    decl Davg = double(-2*meanc(mChainInfo[][1]));
    decl pV = double(0.5*varc(mChainInfo[][1]));
    decl Dhat = 0;
    for (c=0;c<cC;c++)
      Dhat += -2*vars[c].LogLikelihood(amSumCoefs[c]/opt.cDraws,amSumResVar[c]/opt.cDraws);
    decl pD = Davg - Dhat;
    decl DIC = Davg + pD; 
    mDICreport[2][] = Davg~pD~DIC;
 
    print("Mean Post. Deviance: ",Davg,", pV: ","%.2f", pV, ", pD: ", "%.2f", pD, ", DIC: ", DIC,"\n");   
    
    print("Deviance report","%r",{"bu","po","hp"},"%c",{"Davg","pD","DIC"},mDICreport);

    /* save chain info */
    savemat("out/chaininfo.fmt",mChainInfo);

    /* report lambda(s) */
    for (decl lam=0; lam<sizeof(Lrowsel); lam++)
      ReportScalar1Chain(vlam[][lam], mChainInfo, sprint("out/lam",lam,"-",iChain,".mat"));
    
    /* country irfs */
    for (c=0;c<cC;c++)
      {
        mtoplot = quantilec(amirf[c], opt.vQuant);
        DrawIRFs(c*cY, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]},
                 sp.asEndoNames, -1, sp.iShock,"out/irf-hp-"~sp.aCountries[c][0]~"-");
      }    
    SaveDrawWindow("out/irfs-hp.eps");
    CloseDrawWindow();
    
    /* mean irfs */
    mtoplot = quantilec(mirf, opt.vQuant);
    DrawIRFs(0, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]}, sp.asEndoNames, -1, sp.iShock,"out/irf-hp-mean-");
    SaveDrawWindow("out/irfs-hp-mean.eps");
    CloseDrawWindow(); 
    /* save the whole distribution of mean responses */
    savemat(sprint("out/irf-hp-mean.fmt"),mirf);
    
    /* report on sacrifice ratio */
    ReportSacrifice(mirf,0,1,sp.iShock,cY,opt.cMAlags-1,"out/sacrifice-hp");
    ReportSacrifice(mirf,0,1,sp.iShock,cY,23,"out/sacrifice-hp");

    /* residuals */
    for (c=0;c<cC;c++)
      {
        amcres[c].Report("out/err-hp-"~sp.aCountries[c][0],vars[c]);
      }
    
    /* numerical problems */
    print("numerical problems:", "%c",{"invertsym","choleski","total"},
          (merrors~sumr(merrors))|((merrors~sumr(merrors))./iChainLength));
        
  } // Bayesian pooling done

  fclose("l");  
  systemcall("ping -n 2 localhost"); //waste some time so plots can finish
  systemcall("mv *.eps out");
  // print(systemcall("makereport.py "~sp.sSpecName));
  systemcall("mv out "~sp.sSpecName);
}