#include <oxstd.h>

const decl EXT = ".csv";

#include "spec.ox"
#include "dummyarrows.ox"
#include "factorizations.ox"
#include "estimate.ox"


struct Options
{
  decl cBurnout;
  decl cThin;
  decl cDraws;
  decl cChains, cChainsPooled;
  decl cMAlags;
  decl vQuant;

  Info();
};

Options::Info()
{
  print("\n",timestr(today()),"\n*** Total Draws: ",cBurnout+cThin*cDraws,
        " = ",cBurnout," + ",cThin,"*",cDraws,"stored draws ***\n\n");
}

main()
{
  
  /* opt - struct with parameters (options) of the simulation */
  decl opt = new Options();
  opt.cBurnout = 10000/1000;
  opt.cThin = 1000/1000;
  opt.cDraws = 1000;
    
  opt.cChains = 2, opt.cChainsPooled = 1;

  opt.cMAlags = 36;
  opt.vQuant = <0.5,0.05,0.95,0.16,0.84>;

  decl sp; // specification struct
  decl sp_fFact; // factorizing function

  decl aWorld = {"lnoil-eur",0,1,"lnnfd-eur",0,1};
  decl aUS = {"ffr",0,1};
  decl aGer = {"r-mkt-ger",0,1,"lnipsa-ger",1,2,"lneur-usd",0,1};

  systemcall("rm -r out");
  systemcall("rm *.eps");
  systemcall("rm *.txt");
  
  decl deps;

  /* include specification files here */ 
  sp = new Spec();
 #include "spec-cee-06.ox"
//  estimate(opt,sp,sp_fFact);

  sp = new Spec();
#include "spec-emu-06.ox"
  estimate(opt,sp,sp_fFact);

// include other spec-... files analogously


  exit(0);
  /* informative prior for lambda */
  deps = 0.1;
  sp = new Spec();
 #include "spec-cee-06.ox"
  sp.s = deps; sp.v = deps; sp.sSpecName = sprint(sp.sSpecName,"-",deps);
  estimate(opt,sp,sp_fFact);

#include "spec-emu-06.ox"
  sp.s = deps; sp.v = deps; sp.sSpecName = sprint(sp.sSpecName,"-",deps);
  estimate(opt,sp,sp_fFact);



}

