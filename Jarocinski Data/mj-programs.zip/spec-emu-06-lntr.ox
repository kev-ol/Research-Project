{
  sp.sSpecName = "spec-emu-06-lntr";
  
  /* set data specification */
  sp.sDataFilePath = "../data/2008-euro/";
  sp.asExogDataFiles = {"../data/2008-world/world1"~EXT,"../data/2008-world/dummies"~EXT};
  
  sp.cARlags = 6;
  sp.asEndoNames = { "lnipsa", "lncpi", "r-mkt", "lndem", "lntr" };
  sp.aExogWSel = aWorld~aUS;
  
  decl aExogZSel = {"Constant",0,0}~aGer;
  decl sCommonSample = "1987 (1) - 1998 (12)";
  
  sp.aCountries = {};
  sp.aCountries |= {{"finland",aExogZSel,sCommonSample}};
  sp.aCountries |= {{"france",aExogZSel,sCommonSample}};
  sp.aCountries |= {{"italy",aExogZSel,sCommonSample}};
  sp.aCountries |= {{"portugal",aExogZSel,sCommonSample}};
  sp.aCountries |= {{"spain",aExogZSel,sCommonSample}};
  
  /* set factorization */
  sp_fFact = FactSignmjqr_tr; 
  sp.iShock = strfind(sp.asEndoNames,"r-mkt");
  
  /* set prior */
  sp.s = 0; sp.v = -1;
  
  sp.sLtype = "m1";
}  
