#ifndef DUMMYARROWS_INCLUDED
#define DUMMYARROWS_INCLUDED

#import "packages/mj/mj"

/* extract the specified dummies
   and prepare arrows that signal them on the graph 
   (in gnuplot)
*/

DummyArrows(const aCountries);
dummyarrows(const sOutFile, const aSel);
dummydates(const aSel);
yytoyyyy(const iyy, const icutoff);

DummyArrows(const aCountries)
{
  for (decl c=0;c<sizeof(aCountries);c++)
    dummyarrows(sprint("arrows-",aCountries[c][0],".txt"),aCountries[c][1]);
}

dummydates(const aSel)
{
  decl mDates = <>;
  decl adate, iyear0, iperiod0, ifreq = 12, iyear1, iperiod1;

  for (decl i=0;i+2<sizeof(aSel);i+=3)
    {
      /* check if the current segment refers to a dummy */
      if (!(sizeof(aSel[i])==5 && aSel[i][0]=='d')) continue;
      sscan(aSel[i],"d%2u",&iyear0,"%2u",&iperiod0);
      iyear0 = yytoyyyy(iyear0,40);
      
      for (decl l=aSel[i+1];l<=aSel[i+2];l++)
        {
          [iyear1,iperiod1] = mj::LagDate(iyear0, iperiod0, ifreq, -l);
          mDates |= matrix(iyear1)~matrix(iperiod1);
        }      
    }
  return mDates;
}

dummyarrows(const sOutFile, const aSel)
{
  decl f = fopen(sOutFile,"w");
  decl mdates = dummydates(aSel);
  for (decl i=0;i<rows(mdates);i++)
    {
      fprintln(f,"set arrow from '",mdates[i][0],"-",mdates[i][1],"-01',amin to '",
               mdates[i][0],"-",mdates[i][1],"-01',amax nohead ls 9");
    }
  fclose(f);
}

yytoyyyy(const iyy, const icutoff)
{
  if (iyy<icutoff) return 2000+iyy;
  else return 1900+iyy;
}

#endif /* DUMMYARROWS_INCLUDED */
