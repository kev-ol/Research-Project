#import "packages/arrayutils/arr"

DevianceReport(const var, const mPostDraws);


DevianceReport(const var, const mPostDraws)
{
  decl cDraws = rows(mPostDraws);
  decl vlogl = zeros(cDraws,1);
  decl mCoefs, mResVar;
  
  for (decl i=0;i<cDraws;i++)
    {
      [mCoefs,mResVar] = Arr::UnVec(mPostDraws[i][],{var.mB(),var.mUtU()});
      vlogl[i] = var.LogLikelihood(mCoefs,mResVar);
    }
  
  [mCoefs,mResVar] = Arr::UnVec(meanc(mPostDraws),{var.mB(),var.mUtU()});
  
  decl Davg = double(-2*meanc(vlogl));
  decl pV = double(2*varc(vlogl));
  decl Dhat = double(-2*var.LogLikelihood(mCoefs,mResVar));
  decl pD = Davg - Dhat;
  decl DIC = Davg + pD;
  
  print("Mean Post. Deviance: ",Davg,", pV: ","%.2f", pV, ", pD: ", "%.2f", pD, ", DIC: ", DIC,"\n");

  return Davg~pD~DIC;

}