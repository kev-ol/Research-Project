#include <lib/densest.h>
#include <packages/gnudraw/gnudraw.h>


ReportScalar1Chain(const vDraws, const vDrawNr, const sPath);
ReportScalarMultipleChains(const asFiles);


ReportScalar1Chain(const vDraws, const mChainInfo, const sPath)
{
    savemat(sPath,vDraws);
    decl mtoplot = DensEst(vDraws, 0, maxc(vDraws), -1, 64);
    DrawXMatrix(0,mtoplot[2][],"density",mtoplot[0][],"parameter");    
    DrawXMatrix(1,mtoplot[1][],"histogram",mtoplot[0][],"parameter");        
    DrawXMatrix(2,vDraws',"parameter",mChainInfo[][0]',"draw");
    SaveDrawWindow(sprint(sPath[:sizerc(sPath)-5],".eps"));
    CloseDrawWindow();
}

ReportScalarMultipleChains(const asFiles)
{
  decl m, cM = sizeof(asFiles);
  decl mDraws = <>;
  for (m=0;m<cM;m++)
    {
      mDraws ~= loadmat(asFiles[m]);
    }
  decl n, cN = rows(mDraws);
  
  decl vMeans = meanc(mDraws);
  decl B = cN/(cM-1)*cM*varr(vMeans);
  decl W = meanr(cN/(cN-1)*varc(mDraws));
  decl varplus = (cN-1)/cN*W + 1/cN*B;
  decl Rhat = sqrt(varplus/W);
  decl neff = cM*cN*varplus/B;
  
  return Rhat;
}