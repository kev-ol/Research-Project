#include "packages/var/extractirfs.ox"
#import "lib/densest"
#include "packages/gnudraw/lib/libkern.ox"
#include <packages/gnudraw/gnudraw.h>
#include "packages/writecsv/writecsv.ox"

sacrifice(const mirf, const iOutput, const iPricelevel, const iShock, const cY)
// return cDraws x cMAlags matrix with sacrifice ratios for all draws and all lags
{
  decl moutputlost, mcumuloutputlost, dpricechange;
  decl cperiods = columns(mirf)/(cY^2);
  
  moutputlost = extractIRFs(mirf,iOutput, iShock, -1, cY);
  
  mcumuloutputlost = (cumulate(moutputlost')./range(1,cperiods)')';
  dpricechange = extractIRFs(mirf,iPricelevel, iShock, -1, cY);
  
  return mcumuloutputlost./dpricechange;
}

ReportSacrifice(const mirf, const iOutput, const iPricelevel, const iShock, const cY, const vHorizons, const sPath)
{
  decl msacr = sacrifice(mirf,iOutput,iPricelevel,iShock,cY);

  /* plot quantiles for all horizons */
  decl mtoplot = quantilec(msacr,<0.5,0.16,0.84>);
  DrawMatrix(0,mtoplot,0,0,1);
  SaveDrawWindow(sPath~".eps");
  CloseDrawWindow();

  if (vHorizons<0) return;

  decl ihor,vsacr;
  for (decl i=0;i<sizerc(vHorizons);i++)
    {
      ihor = vHorizons[i];
      vsacr = msacr[][ihor];
      savemat(sprint(sPath,"-",ihor,".fmt"),vsacr);

      /* use lib/DensEst */
      mtoplot = DensEst(vsacr, -5, 15, 0.5, 128);
      DrawXMatrix(0, mtoplot[2][], {}, mtoplot[0][],"");
      SaveDrawWindow(sprint(sPath,"-dens-h",ihor,".eps"));
      CloseDrawWindow();
      writecsv(sprint(sPath,"-dens-h",ihor,".csv"),mtoplot');

      /* use gnudraw/lib/libkern */
      decl xpoints = range(-5,15,0.2);
      s_KernelUni(xpoints, vsacr', &mtoplot);
      DrawXMatrix(0, mtoplot, {}, xpoints,"");
      SaveDrawWindow(sprint(sPath,"-dens-h",ihor,"g.eps"));
      CloseDrawWindow();
      writecsv(sprint(sPath,"-dens-h",ihor,"g.csv"),(xpoints|mtoplot)');
    }
}