#ifndef MCRESID_INCLUDED
#define MCRESID_INCLUDED

#include <packages/gnudraw/gnudraw.h>
#import <lib/testres>
#import "packages/mj/mj"
#import "packages/arrayutils/arr"
#include "packages/writecsv/writecsv.ox"

/* class for checking residuals obtained in each step
   of a MonteCarlo simulation
*/

class MCResid
{
  decl m_cDim, m_cT, m_cDraws;
  decl m_mUs;
  decl m_mUstats;

  Initialize(const cT, const cDim, const cDraws, const bStoreU);
  StoreDraw(const draw, const mU);
  Report(const sFileName, const oInfo);
  ReportUs(const sFileName, const oInfo);
  ReportStats(const sFileName);
  SetUs(const mUs, const cDim); // setting U's directly, whole matrix
};

CheckNormality(const mU, const iPrint);
varResidualReport(const mPostDraws, const sFileName, const var, const fFact, const bStoreU);

MCResid::Initialize(const cT, const cDim, const cDraws, const bStoreU)
{ m_cT = cT;
  m_cDim = cDim;
  m_cDraws = cDraws;
  m_mUstats = zeros(m_cDraws, 7);
  if (bStoreU) m_mUs = zeros(m_cDraws, m_cT*m_cDim);
  else m_mUs = <>;
}

MCResid::StoreDraw(const draw, const mU)
{
  if (sizeof(m_mUs)) m_mUs[draw][] = vec(mU)';
  decl ret;
  ret = CheckNormality(mU,0);
  m_mUstats[draw][0:2] = ret[1]';
  ret = PortmanteauTest(mU,4,0,0);
  m_mUstats[draw][3] = ret[0];
  ret = PortmanteauTest(mU,8,0,0);
  m_mUstats[draw][4] = ret[0];
  ret = PortmanteauTest(mU,12,0,0);
  m_mUstats[draw][5] = ret[0];
  ret = NormalityTest(mU,0);
  m_mUstats[draw][6] = ret[0];
}

MCResid::Report(const sFileName, const oInfo)
{
  ReportUs(sFileName, oInfo);
  ReportStats(sFileName);
}

MCResid::ReportUs(const sFileName, const oInfo)
{
  if (sizeof(m_mUs)==0)
    {
      oxwarning("Skip reporting U's, no Us given");
      return;
    }
  decl mUi, malltoplot = <>, mtoplot;
  for (decl i=0;i<m_cDim;i++)
    {
      mUi = m_mUs[][i*m_cT:(i+1)*m_cT-1];
      mtoplot = quantilec(mUi, <0.5>);
      DrawT(i,mtoplot,
            oInfo.GetYear1(), oInfo.GetPeriod1(), oInfo.GetFrequency());
      DrawTitle(i,sprint("eps",i));
      malltoplot ~= mtoplot';
    }
  SaveDrawWindow(sFileName~".eps");
  CloseDrawWindow();
  writecsvdated(sFileName~".csv", malltoplot,oInfo);
}

MCResid::ReportStats(const sFileName)
{
  decl aTests = {};
  aTests |= {{"means",m_cDim}};
  aTests |= {{"skews",m_cDim}};
  aTests |= {{"kurts",m_cDim}};
  aTests |= {{"PortmanteauTest(4)",m_cDim^2*4}};
  aTests |= {{"PortmanteauTest(8)",m_cDim^2*8}};
  aTests |= {{"PortmanteauTest(12)",m_cDim^2*12}};
  aTests |= {{"NormalityTest",2*m_cDim}};

  /* plot stats */
  decl SigLev = 0.95;
  decl crit, pval, x, y;
  for (decl i=0;i<6;i++)
    {
      crit = quanchi(SigLev,aTests[i][1]);
      pval = sumc(m_mUstats[][i].>crit)/m_cDraws;
      [x,y] = DrawDensity(i,m_mUstats[][i]',sprint(aTests[i][0]," p=",double(pval)));
      DrawLine(i,crit,0,crit,maxc(y'),2);
    }

  SaveDrawWindow(sFileName~"-stats.eps");
  CloseDrawWindow();  
}

MCResid::SetUs(const mUs, const cDim)
{
  this->Initialize(columns(mUs)/cDim,cDim,rows(mUs),1);
  m_mUs = mUs;
}

/**********************end of class********************************/

CheckNormality(const mU, const iPrint)
/* checks if mU comes from a normal distribution
** in case mU has multiple columns, assumes they are orthogonalized
*/
{
  /* means, skewness, kurtosis */
  decl mom = dropr(moments(mU),<0,2>);
  mom[2][] -= 3; // convert to excess kurtosis
  
  if (iPrint) print("%r",{"mean","skew","ex.kurt"},mom);
  
  /* this is a vector of chi2(K) where K is number of columns in U
  ** see Lutkepohl (2005) p.176 */
  decl vNormStat = rows(mU)*sumr(sqr(mom)).*<1;1/6;1/24>;
  if (iPrint)
    {
      println("");
      println("mean: "~mj::ReportChi2(vNormStat[0],columns(mU)));
      println("skew: "~mj::ReportChi2(vNormStat[1],columns(mU)));
      println("kurt: "~mj::ReportChi2(vNormStat[2],columns(mU)));
    }
  return {mom, vNormStat};
}

varResidualReport(const mPostDraws, const sFileName, const var, const fFact, const bStoreU)
/* utility function that takes output of a VAR posterior simulator, computes errors
   at each draw, stores them in the MCResid class and generates the report */
{
  decl mcres = new MCResid();
  mcres.Initialize(var.cT(), var.cY(), rows(mPostDraws), bStoreU);

  decl mCoefs_d, mResVar_d, mU_d;
  for (decl draw=0;draw<rows(mPostDraws);draw++)
    {
      [mCoefs_d, mResVar_d] = Arr::UnVec(mPostDraws[draw][],{var.mB(),var.mUtU()});
      mU_d = (var.mY() - var.mX()*mCoefs_d)*
  invert(fFact(mResVar_d,mCoefs_d[0:var.cYlags()-1][])');
      mcres.StoreDraw(draw,mU_d);
    }
  mcres.Report(sFileName,var);
}

#endif /* MCRESID_INCLUDED */