{
  sp.sSpecName = "spec-emu-06-safe3";
  
  /* set data specification */
  sp.sDataFilePath = "../data/2008-euro/";
  sp.asExogDataFiles = {"../data/2008-world/world1"~EXT,"../data/2008-world/dummies"~EXT};
  
  sp.cARlags = 6;
  sp.asEndoNames = { "lnipsa", "lncpi", "r-mkt", "lndem" };
  sp.aExogWSel = aWorld~aUS;
  
  decl aExogZSel = {"Constant",0,0}~aGer;
  decl sCommonSample = "1987 (1) - 1998 (12)";
  
  sp.aCountries = {};
  sp.aCountries |= {{"finland",aExogZSel~{"d9103",0,25},sCommonSample}};
  sp.aCountries |= {{"france",aExogZSel~{"d9209",0,4,"d9501",0,4},sCommonSample}};
  sp.aCountries |= {{"italy",aExogZSel~{"d9206",0,10,"d9501",0,4},sCommonSample}};
  sp.aCountries |= {{"portugal",aExogZSel~{"d9010",0,6,"d9209",0,10,"d9501",0,4},sCommonSample}};
  sp.aCountries |= {{"spain",aExogZSel~{"d9209",0,8,"d9501",0,4}, "1987(7) - 1998(12)"}};
  
  /* set factorization */
  sp_fFact = FactSignmjqr23;
  sp.iShock = strfind(sp.asEndoNames,"r-mkt");
  
  /* set prior */
  sp.s = 0; sp.v = -1;
  
  sp.sLtype = "m1";
}  
