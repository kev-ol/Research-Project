#include <oxstd.h>
#include "writecsv.ox"
#import <database>

main()
{
  decl cT = 24;
  decl mX = rann(cT,2);

  /* simple writing of csv files */
  writecsv("writecsv-example1.csv",mX);

  /* try how the dates work */
  print(makedates(1999,1,4,cT));

  /* write csv with dates in the first column */
  writecsvdated("writecsv-example2.csv",mX,{1999,1,4});
  
  /* the same, take dates from the database object */
  decl db = new Database();
  db.Create(4,1999,1,2000,1);
  writecsvdated("writecsv-example3.csv",mX,db);

}