#ifndef WRITECSV_INCLUDED
#define WRITECSV_INCLUDED

writecsv(const sFileName, const mData);
writecsvdated(const sFileName, const mData, const aInfo);
makedates(const iYear1, const iPeriod1, const iFreq, const cT);

writecsv(const sFileName, const mData)
{
  decl f = fopen(sFileName,"w");
  for (decl r=0;r<rows(mData);r++)
    {
      for (decl c=0;c<columns(mData);c++)
        {
          fprint(f,mData[r][c]);
          if (c<columns(mData)-1) fprint(f,",");
          else fprint(f,"\n");
        }
    }
  fclose(f);
}

writecsvdated(const sFileName, const mData, const aInfo)
{
  decl cT = rows(mData);
  decl mdates;
  if (isclass(aInfo))
    mdates = makedates(aInfo.GetYear1(),aInfo.GetPeriod1(),aInfo.GetFrequency(),cT);
  else
    mdates = makedates(aInfo[0],aInfo[1],aInfo[2],cT);

  decl f = fopen(sFileName,"w");
  for (decl r=0;r<cT;r++)
    {
      fprint(f,"%d",mdates[r][0],"-","%02d",mdates[r][1],",");
      for (decl c=0;c<columns(mData);c++)
        {
          fprint(f,mData[r][c]);
          if (c<columns(mData)-1) fprint(f,",");
          else fprint(f,"\n");
        }
    }
  fclose(f);
}

makedates(const iYear1, const iPeriod1, const iFreq, const cT)
/* make a T x 2 matrix with year,period for each obs */
{
  decl mdates = zeros(cT, 2);
  decl firstdate = iYear1*iFreq + iPeriod1 - 1;
  decl minp = 12/iFreq;
  for (decl t=0;t<cT;t++)
    {
      mdates[t][0] = idiv((firstdate + t),iFreq);
      mdates[t][1] = imod((firstdate + t),iFreq)*minp + 1;
    }
  return mdates;
}

#endif /* WRITECSV_INCLUDED */