#ifndef DRAWIRFS_INCLUDED
#define DRAWIRFS_INCLUDED

//#include <oxdraw.h>
#include <packages/gnudraw/gnudraw.h>
#include "packages/writecsv/writecsv.ox"

/*
** DrawIRFs - routine for plotting VAR impulse responses
**
**  iFirstArea - index of the first area of the plot
**  amToPlot - array of up to 4 matrices;
**             first matrix plotted with solid line, second with dashed etc.
**             in matrices each row is a complete set of impulse responses,
**             ordered by variable, then by shock
**  asVarNames - names of all the variables in the VAR
**  vVarsToPlot - vector with numbers of variables whose IRFs should be plotted,
**                (-1 -> plot all)
**  vShocksToPlot - vector with number of shocks whose IRFs should be plotted
**                (-1 -> plot all)
**  ... - if the optional argument is a string, 
**        plot data will be saved in '.csv' format to the path given by the string
*/


DrawIRFs(const iFirstArea, const amToPlot, const asVarNames, const vVarsToPlot, const vShocksToPlot, ...)
{
  decl mtoplot_solid, mtoplot_dash, mtoplot_dots, mtoplot_mixed;
  decl cVars, cMAlags;
  decl vvarstoplot, vshockstoplot;
  decl cplotno, cvarnum, cshocknum, cvar, cshock, cseries, i;
  decl vargs = va_arglist();
  
  /************** read arguments *************/
  cVars = sizeof(asVarNames);
  
  /* set mtoplot_.. matrices */
  mtoplot_dash = mtoplot_dots = mtoplot_mixed = <>;
  if (ismatrix(amToPlot)) mtoplot_solid = amToPlot; //can be a matrix, then only solid plot
  else // if array of matrices to plot
    {
      mtoplot_solid = amToPlot[0]; // first matrix plotted with solid line
      if (sizeof(amToPlot)>1) mtoplot_dash = amToPlot[1]; // second matrix plotted with dashed line
      if (sizeof(amToPlot)>2) mtoplot_dots = amToPlot[2]; // third matrix plotted with dotted line
      if (sizeof(amToPlot)>3) mtoplot_mixed = amToPlot[3]; // fourth matrix plotted with mixed line
    }
  /* check dimensions of mtoplot_.. matrices, set cMAlags */
  if (columns(mtoplot_solid)>0)
    cMAlags = columns(mtoplot_solid)/(cVars^2);
  else
    cMAlags = 0;
  if (columns(mtoplot_dash)>0)
    if (cMAlags>0)
      {
        if ( (columns(mtoplot_dash)/(cVars^2))!=cMAlags ) oxrunerror("DrawIRFs: matrices to plot have different numbers of columns!");
      }
    else
      cMAlags = columns(mtoplot_dash)/(cVars^2);
  if (columns(mtoplot_dots)>0)
    if (cMAlags>0)
      {
        if ( (columns(mtoplot_dots)/(cVars^2))!=cMAlags ) oxrunerror("DrawIRFs: matrices to plot have different numbers of columns!");
      }
    else
      cMAlags = columns(mtoplot_dots)/(cVars^2);
  if (columns(mtoplot_mixed)>0)
    if (cMAlags>0)
      {
        if ( (columns(mtoplot_mixed)/(cVars^2))!=cMAlags ) oxrunerror("DrawIRFs: matrices to plot have different numbers of columns!");
      }
    else
      cMAlags = columns(mtoplot_mixed)/(cVars^2);
  
  /* check vars and shocks to plot */
  if (max(vVarsToPlot)>cVars) oxrunerror(sprint("DrawIRFs: don't have ",max(vVarsToPlot)+1," variables!"));
  if (max(vShocksToPlot)>cVars) oxrunerror(sprint("DrawIRFs: don't have ",max(vShocksToPlot)+1," variables!"));
  
  /* if needed, put default value for the vars and shocks to plot */
  if (vVarsToPlot==-1) vvarstoplot = range(0,cVars-1);
  else vvarstoplot = vVarsToPlot;
  if (vShocksToPlot==-1) vshockstoplot = range(0,cVars-1);
  else vshockstoplot = vShocksToPlot;
  

  /************* plots ****************/
  cplotno = iFirstArea;
  for (cshocknum=0;cshocknum<sizerc(vshockstoplot);cshocknum++)
    {
      cshock = vshockstoplot[cshocknum];

      for (cvarnum=0;cvarnum<sizerc(vvarstoplot);cvarnum++)
        {
          cvar = vvarstoplot[cvarnum];
          
          cseries = cvar*cVars+cshock;
          
          /* solid */
          for (i=0;i<rows(mtoplot_solid);i++)
            DrawMatrix(cplotno, mtoplot_solid[i][cseries*cMAlags:(cseries+1)*cMAlags-1], 0, 0, 1, 0, 1);

          /* dash */
          for (i=0;i<rows(mtoplot_dash);i++)
            DrawMatrix(cplotno, mtoplot_dash[i][cseries*cMAlags:(cseries+1)*cMAlags-1], 0, 0, 1, 0, 3);

          /* dots */
          for (i=0;i<rows(mtoplot_dots);i++)
            DrawMatrix(cplotno, mtoplot_dots[i][cseries*cMAlags:(cseries+1)*cMAlags-1], 0, 0, 1, 0, 5);

          /* mixed */
          for (i=0;i<rows(mtoplot_mixed);i++)
            DrawMatrix(cplotno, mtoplot_mixed[i][cseries*cMAlags:(cseries+1)*cMAlags-1], 0, 0, 1, 0, 5);

          /* title */
          DrawTitle(cplotno, sprint(asVarNames[cvar],"<-",cshock));
          
          /* save plot data */
          if (sizeof(vargs)>0)
            writecsv(sprint(vargs[0],asVarNames[cvar],"-",cshock,".csv"),
                     (range(0,cMAlags-1)|(mtoplot_solid|mtoplot_dash|
                     mtoplot_dots|mtoplot_mixed)[][cseries*cMAlags:(cseries+1)*cMAlags-1])');
          cplotno++;
        }
    }
  return cplotno;
}

#endif /* DRAWIRFS_INCLUDED */
