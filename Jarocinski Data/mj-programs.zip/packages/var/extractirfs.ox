#ifndef EXTRACTIRFS_INCLUDED
#define EXTRACTIRFS_INCLUDED


extractIRFs(const mIRFs, const vVars, const vShocks, const vPeriods, const cVars)
{
  decl vvars, vshocks, vperiods;
  decl cvar, cshock;
  decl cPeriods;
  decl i, j;
  decl mresult;

  cPeriods = columns(mIRFs)/(cVars^2);
  
  if (vVars==-1) vvars = range(0,cVars-1);
  else vvars = matrix(vVars);
  if (vShocks==-1) vshocks = range(0,cVars-1);
  else vshocks = matrix(vShocks);
  if (vPeriods==-1) vperiods = range(0,cPeriods-1);
  else vperiods = matrix(vPeriods);

  mresult = <>;
  
  for (i=0;i<columns(vvars);i++)
    {
      cvar = vvars[i];
      for (j=0;j<columns(vshocks);j++)
        {
          cshock = vshocks[j];
          mresult ~= mIRFs[][vperiods + (cvar*cVars+cshock)*cPeriods];
        }
    }
  return mresult;
}

irfrange(const vVars, const vShocks, const vPeriods, const cVars, const cPeriods)
/* range corresponding to vVars, vShocks and vPeriods in the vectorized irf
** for 'all' give -1 */
{
  decl vvars, vshocks, vperiods;
  decl cvar, cshock;
  decl i, j;
  decl mresult;
  
  if (vVars==-1) vvars = range(0,cVars-1);
  else vvars = matrix(vVars);
  if (vShocks==-1) vshocks = range(0,cVars-1);
  else vshocks = matrix(vShocks);
  if (vPeriods==-1) vperiods = range(0,cPeriods-1);
  else vperiods = matrix(vPeriods);

  mresult = <>;
  
  for (i=0;i<columns(vvars);i++)
    {
      cvar = vvars[i];
      for (j=0;j<columns(vshocks);j++)
        {
          cshock = vshocks[j];
          mresult ~= vperiods + (cvar*cVars+cshock)*cPeriods;
        }
    }
  return mresult;
}

#endif /* EXTRACTIRFS_INCLUDED */
