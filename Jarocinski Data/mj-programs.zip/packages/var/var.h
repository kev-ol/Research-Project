#ifndef VAR_INCLUDED
#define VAR_INCLUDED

#import <database>
#import "packages/mj/mj"

class VAR
{
  /* data */
  decl m_mY;
  decl m_mYlags;
  decl m_mExog;
  
  decl m_asY, m_aExogSel;
    
  decl m_cARlags;
  
  decl m_sRequestedSample, m_sEffectiveSample;
  decl m_iFreq;
  decl m_sInfo;
  
  /* some functions of data */
  decl m_mXtXinv, m_mXtX, m_mXtY, m_mYtY;
  
  /* OLS estimates */
  decl m_mB;
  decl m_mUtU;
  
  
  VAR();
  
  /* loading */
  SetSample(const sSample);
  SetEndoNames(const asEndoNames);
  SetExogSel(const aExogSel);
  SetARlags(const cARlags);
  LoadData(const sDataFile, const iMsgLevel); // loads the desired file(s)
                              //and calls ExtractData passing the database object
  virtual ExtractData(const dbase); // extracts the data from the passed database
  virtual PlotData();
  GetYear1();
  GetPeriod1();
  GetFrequency();
  
  estimateols();
  
  /* setting data externally */
  SetData(const mY, const mYlags, const mExog);
  
  ResInner(const mCoefs);
  LogLikelihood(const mCoefs, const mResVar);
  
  /* getting simple things */
  mY();
  mX();
  mYlags();
  mExog();
  cY();
  cX();
  cARlags();
  cYlags();
  cT();
  Info();
  mB();
  mARrep();
  mUtU();
  mXtX();
  mXtXinv();
  mXtY();
  mY0();

  asY();
};

#endif /* VAR_INCLUDED */
