
VAR::VAR()
{
  m_sRequestedSample = "-1 (-1) - -1 (-1)";
  m_aExogSel = {};
}

VAR::SetSample(const sSample)
{
  m_sRequestedSample = sSample;
}

VAR::SetEndoNames(const asEndoNames)
{
  m_asY = asEndoNames;
}

VAR::SetExogSel(const aExogSel)
{
  m_aExogSel = aExogSel;
}


VAR::SetARlags(const cLags)
{
  m_cARlags = cLags;
}

VAR::LoadData(const asfiles, const iMsgLevel)
{
  decl asfilestoload, dbase;

  if (isstring(asfiles)) asfilestoload = {asfiles};
  else asfilestoload = asfiles;

  dbase = mj::DbMergeFromFiles(asfilestoload,iMsgLevel);
  dbase.Deterministic(0);
  this->ExtractData(dbase);
}

VAR::ExtractData(const dbase)
{
  print("extracting variables\n");
  
  m_iFreq = dbase.GetFrequency();
  
  /* create aendosel from asY and cARlags */
  decl aendosel = new array[0];
  for (decl j=0;j<sizeof(m_asY);j++)
    {
      aendosel ~= {m_asY[j],0,m_cARlags};
    }
  
  /* check if all variables are there */
  mj::CheckForVars(m_asY~mj::NamesInSel(m_aExogSel),dbase);
    
  /* select needed variables */
  dbase.Select(0,aendosel);
  dbase.Select(1,m_aExogSel);
  /* set effective sample */
  dbase.SetSelSample(mj::ScanSampleText(m_sRequestedSample));
  m_sEffectiveSample = dbase.GetSelSample();
  /* extract variables*/
  m_mY = dbase.GetGroupLag(0,0,0);
  m_mYlags = <>;
  for (decl l=1;l<=m_cARlags;l++)
    {
      m_mYlags ~= dbase.GetGroupLag(0,l,l);
    }
  m_mExog = dbase.GetGroup(1);

  /* now print out some info */
  println("Requested sample: ",m_sRequestedSample);
  println("Effective sample: ",m_sEffectiveSample);
  println("Total observations: ",cT());
  println("Coefficients per equation: ",cX());
  print("Info: ",Info(),"\n\n"); 
  
  this->estimateols();
}

VAR::estimateols()
{
  decl ols_result = olsc(mY(), mX(), &m_mB, &m_mXtXinv, &m_mXtX);
  if ( ols_result < 1 )
    {
      oxrunerror(sprint("problem in OLS, olsc return: ", ols_result),1);
    }
  m_mUtU = outer(mY() - mX()*m_mB,<>,'o');
  m_mYtY = outer(mY(),<>,'o');
  m_mXtY = m_mXtX*m_mB;
}


VAR::Info()
{
  return sprint("ARlags:",m_cARlags,";",mj::DbSel2Text(m_aExogSel));
}


VAR::PlotData()
{
  for (decl j=0;j<cY();j++)
    {
      DrawT(j,m_mY[][j]',GetYear1(),GetPeriod1(),GetFrequency());
      DrawTitle(j,m_asY[j]);
    }
}

VAR::GetYear1()
{
  return mj::ScanSampleText(m_sEffectiveSample)[0];
}
VAR::GetPeriod1()
{
  return mj::ScanSampleText(m_sEffectiveSample)[1];
}
VAR::GetFrequency()
{ return m_iFreq; }



VAR::SetData(const my, const mylags, const mexog)
{
  m_mY = my;
  m_mYlags = mylags;
  m_mExog = mexog;
  m_cARlags = cYlags()/cY();
  if (m_cARlags != floor(m_cARlags)) oxrunerror(sprint("SetData: cY: ",cY(),", cYlags: ",cYlags(),", so cARlags: ",cARlags()));
  m_cARlags = int(m_cARlags);
  println("Total observations: ",cT());
  println("Coefficients per equation: ",cX());
  print("Info: ",Info(),"\n\n"); 
  this->estimateols();
}

VAR::ResInner(const mCoefs)
{
  decl mBtXtY;
  mBtXtY = mCoefs'*m_mXtY;
  return m_mYtY - mBtXtY - mBtXtY' + outer(mCoefs',m_mXtX);      
}

VAR::LogLikelihood(const mCoefs, const mResVar)
{
  decl sign;
  return double( - 0.5*cY()*cT()*log(M_2PI) - 0.5*cT()*logdet(mResVar,&sign)
		 - 0.5*trace(ResInner(mCoefs)*invertsym(mResVar)) );
}


VAR::mY() { return m_mY; }
VAR::mX() { return m_mYlags~m_mExog; }
VAR::mYlags() { return m_mYlags; }
VAR::mExog() { return m_mExog; }
VAR::cY() { return columns(m_mY); }
VAR::cX() { return columns(m_mYlags)+columns(m_mExog); }
VAR::cARlags() { return m_cARlags; }
VAR::cYlags() { return columns(m_mYlags); }
VAR::cT() { return rows(m_mY); }
VAR::mB() { return m_mB; }
VAR::mARrep() { return m_mB[:columns(m_mYlags)-1][]; }
VAR::mUtU() { return m_mUtU; }
VAR::mXtX() { return m_mXtX; }
VAR::mXtXinv() { return m_mXtXinv; }
VAR::mXtY() { return m_mXtY; }
VAR::mY0()
{
  return reversec(reshape(m_mYlags[0][],m_cARlags,this->cY()));
}

VAR::asY() { return m_asY; }

