#ifndef VAR_RATS_INCLUDED
#define VAR_RATS_INCLUDED

#import "packages/var/var"

VAR_rats(const var, const cDraws, const Info, const amPost)
{
  decl mS_chol = choleski(var.mUtU());
  decl mXtXinv_chol = choleski(var.mXtXinv());
  
  decl cdeg = var.cT();

  amPost[0] = zeros(cDraws,sizerc(var.mB()) + sizerc(var.mUtU()));
  
  decl mCoefs_d, mResVar_d;
  for (decl i=0;i<cDraws;i++)
    {
      mResVar_d = mj::RanIWishart(mS_chol, cdeg);
      mCoefs_d = var.mB() + mXtXinv_chol*rann(var.cX(),var.cY())*choleski(mResVar_d)';

      amPost[0][i][] = (vec(mCoefs_d)|vec(mResVar_d))';
    }
}

#endif /* VAR_RATS_INCLUDED */