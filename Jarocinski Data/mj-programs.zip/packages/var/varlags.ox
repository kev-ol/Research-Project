#ifndef VARLAGS_INCLUDED
#define VARLAGS_INCLUDED

// based on a GAUSS proc by Alan G. Isaac
varlags(const mData, const cmaxlag)
{
  decl mY,mYlags,lag,mT;
  if ( rows(mData)<=cmaxlag ) {oxrunerror("VARlags error: too long lags!",1); }
  if ( !isint(cmaxlag) ) {oxrunerror(sprint("VARlags: lags are not integer! lags = ",cmaxlag), 1); }
  if ( cmaxlag<1 ) {oxrunerror("VARlags error: lags should be a positive integer!",1); }

  mY = mData[cmaxlag:][];
  mT = rows(mY);
  mYlags = <>;
  for ( lag=1;lag<=cmaxlag ;lag++ )
    {
      mYlags ~= mData[(cmaxlag-lag):(cmaxlag-lag+mT-1)][];
    }
  return { mY, mYlags };
}

#endif /* VARLAGS_INCLUDED */