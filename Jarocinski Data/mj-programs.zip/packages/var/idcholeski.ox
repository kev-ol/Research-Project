// safe choleski which takes and ignores the second argument
idcholeski(const mResVar, const mARrep)
{
  decl mchol = choleski(mResVar);
  if (ismatrix(mchol)) return mchol; else oxrunerror(sprint("Matrix ",mResVar," does not have choleski decomposition!"));
}
