#ifndef VARIRFS_INCLUDED
#define VARIRFS_INCLUDED


#import "packages/mj/mj"
#import "packages/arrayutils/arr"


irfsdraws(const var, const mPostDraws, const fFact, const cStep, const adirfsdraws);
varirf(const mARrep, const mResVar_fact, const cStep);
var2ma(const mARrep, const cMAlags); // through companion matrix
var2ma1(const mARrep, const cMAlags); // through Gustavo's formula
vardecomp(const vIRFs, const cVars, const cStep);


irfsdraws(const var, const mPostDraws, const fFact, const cStep, const adirfsdraws)
/* matrix of irf draws, from a var object and a matrix of coefficients draws
 (e.g. from a posterior simulator) */
{
  decl cDraws = rows(mPostDraws);
  adirfsdraws[0] = zeros(cDraws, cStep*var.cY()^2);
  
  decl mCoefs_d, mResVar_d;
  for (decl i=0;i<cDraws;i++)
    {
      [mCoefs_d, mResVar_d] = Arr::UnVec(mPostDraws[i][],{var.mB(),var.mUtU()});
      adirfsdraws[0][i][] = varirf(mCoefs_d[0:var.cYlags()-1][],
				    fFact(mResVar_d,mCoefs_d[0:var.cYlags()-1][]), cStep);
    }
}

varirf(const mARrep, const mResVar_fact, const cStep)
/* vectorized, first by variable, then by shock, i.e. var1shock1, var1shock2,... */
{
  decl mirf = var2ma1(mARrep, cStep)*mResVar_fact;
  mirf = mj::Reshape(mirf,cStep,columns(mARrep)^2);
  return vec(mirf)';
}


var2ma(const mARrep, const cMAlags) // through companion matrix
// here cMAlags are MA lags including lag 0!!!
// mARrep is as from the olsc, i.e. (cY*cLags x cY)
// MA representation, m_cMAlags of (cY x cY) matrices stacked vertically!
{
  //measure inputs
  decl cN, cP, cNP;
  cN = columns(mARrep);
  cNP = rows(mARrep);
  cP = cNP/cN;
  if (floor(cP)<cP) oxrunerror("incorrect AR representation?");
  
  //create F-matrix (Hamilton, p.259)
  decl mF;
  mF = zeros(cNP,cNP);
  mF[0:cN-1][]=mARrep';
  if (cP>1) mF[cN:][:cNP-cN-1]=unit(cNP-cN);
    
  //obtain MA representation
  decl mMArep, mFj;
  mMArep = unit(cN);
  decl clag;
  mFj=mF;
  for ( clag=1; clag<cMAlags ; clag++ )
    {
      mMArep|=mFj[:cN-1][:cN-1]; //! vertically stacked Psi matrices
      mFj=mFj*mF;
    }
  return mMArep;
}

var2ma1(const mARrep, const cMAlags) // through Gustavo's formula
// here cMAlags are MA lags including lag 0!!!
// mARrep is as from the olsc, i.e. (cY*cLags x cY)
{
  decl mMArep;
  decl mTemp;
  
  // measure inputs
  decl cY = columns(mARrep);
  decl cARlags = rows(mARrep)/cY;
  if (floor(cARlags)<cARlags) oxrunerror("incorrect AR representation?");


  // put ARrep into an array
  decl amARrep = new array[cARlags];
  for (decl i=0;i<cARlags;i++)
       amARrep[i] = mARrep[i*cY:(i+1)*cY-1][]';

  decl amMArep = new array[cMAlags];
  amMArep[0] = unit(cY);
  
  // compute MArep
  mMArep = unit(cY);
  for (decl i=1;i<cMAlags;i++)
    {
      mTemp = zeros(cY,cY);
      for (decl j=0;j<min(cARlags,i);j++)
        {
           mTemp += amARrep[j]*amMArep[i-j-1];
        }
      amMArep[i] = mTemp;
      mMArep |= amMArep[i];
    }
  
  return mMArep;
}

vardecomp(const vIRFs, const cVars, const cStep)
/* 
** Short variance decomposition, presents shares of variance accounted for by different shocks
** Input: vIRFs - cVAR * cVar * cStep impulse response row vector
**                 sorted by variable, then by shock (as produced by varirf())
**                 e.g. use the output of VARfn::getIRF(const mARrep,const mResVar_fact,const cPeriods)
** Output: cVAR * cVar * cStep row vector with shares of variance (btw.0 and 1),
**                 sorted the same way as the vIRFs
*/
{
  decl mrowsqrshaped, mdecompshaped, mdecompcur, i;
  
  mrowsqrshaped = mj::Shape(vIRFs.^2,cStep,cVars^2); // square and shape so that individual responses (now squared) are in subsequent columns
  mdecompshaped = zeros(mrowsqrshaped); // variance shares will be stored in the same size matrix
  for (i=0;i<cStep;i++) // for each horizon from 0 to cStep
    {
      mdecompcur = mj::Reshape(sumc(mrowsqrshaped[0:i][]),cVars,cVars); //sum the squard IRF up to horizon i; then put in a square matrix cVars (variables) x cVars (shocks)
      mdecompcur = mdecompcur./sumr(mdecompcur); // divide by totals for each variable
      mdecompshaped[i][] = vecr(mdecompcur)';
    }
  return vec(mdecompshaped)'; // the same: by var, then by shock, now decompositions
}


#endif /* VARIRFS_INCLUDED */
