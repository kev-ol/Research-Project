#ifndef VARROOTS_INCLUDED
#define VARROOTS_INCLUDED

/* a collection of static functions for VARs */
class VARroots
{
  static MaxRoot(const mARrep);
  static AbsRoots(const mARrep); // returns a vector of sorted absolute values of roots
  static reportroots(const mARrep); // prints a table with roots, return the same as GetAbsRoots
  static Companion(const mARrep); // makes the companion matrix of the given AR process
};



VARroots::MaxRoot(const mARrep)
{
  decl mRoots;
  eigen(Companion(mARrep),&mRoots);
  return max(cabs(mRoots));
}

VARroots::AbsRoots(const mARrep)
/* returns the absolute roots sorded in decreasing order */
{
  decl mRoots;
  eigen(Companion(mARrep),&mRoots);
  return reverser(sortr(cabs(mRoots)));
}

VARroots::reportroots(const mARrep)
/* mARrep is as from the olsc, i.e. (cY*cLags x cY) */
/* as GetAbsRoots, but also prints a table of roots */
{
  decl mRoots,vAbsRoots,vIndex;
  eigen(Companion(mARrep),&mRoots);
  vAbsRoots = cabs(mRoots);
  vIndex = reversec(sortcindex(vAbsRoots));
  vAbsRoots = vAbsRoots[][vIndex];
  mRoots = mRoots[][vIndex];
  print("Roots:","%c",{"abs","re","i"},vAbsRoots'~mRoots');
  return vAbsRoots;
}

VARroots::Companion(const mARrep)
/* mARrep is as from the olsc, i.e. (cY*cLags x cY) */
{
  decl cY,cYlags,mF;
  cY = columns(mARrep);
  cYlags = rows(mARrep);
  mF = zeros(cYlags,cYlags);
  mF[0:cY-1][] = mARrep';
  if (cYlags>cY)
    mF[cY:][:cYlags-cY-1]=unit(cYlags-cY);
  return mF;
}


#endif /* VARROOTS_INCLUDED */
