#ifndef AR_INCLUDED
#define AR_INCLUDED

#import "packages/mj/mj"


class Ar
{

  static Vecr(const am);
  static VecLength(const am);
  static MatrixVecLength(const ma);

  static Unvecr(const va, const amExample);

  static calculateranges(const am, const func);
  static VecRanges(const am);
  static VcatRanges(const am);
  static HcatRanges(const am);

  static Vcat(const am);
  static Hcat(const am);
  static Diag(const am);

  static IsEq(const am1, const am2);

  static Sum(const am);
  static Mean(const am);
  static SumLogDet(const am);

  static ApplyFunc(const am, const func, ...);
};

#endif /* AR_INCLUDED */
