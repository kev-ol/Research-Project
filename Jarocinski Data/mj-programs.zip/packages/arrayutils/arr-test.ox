#include <oxstd.h>

#import "arr"
#include "packages/mj/operators.ox"

main()
{
  decl s,t,u,v,w,x,y,z;
  decl arr1,arr2,arr3,arr4;
  decl vec1,vec2,vec3,vec4;
  decl mat1,mat2,mat3,mat4;

  s = matrix(1);
  t = matrix(2);
  u = matrix(3);
  v = constant(1,2,2);
  w = constant(2,1,2);
  x = constant(3,2,2);
  y = unit(2);
  z = <1,2;3,4;5,6>;

  print("\n\n**********************\n");
  print("* Arr class version ",Arr::GetVer(),"\n");
  print("**********************\n");
  print("Test of the functions\n\n");

  arr1 = {s,{t,y},z};
  print("\nFunctions: Arr::Vec, Arr::VecRanges, Arr::VecLength, Arr::UnVec\n");
  print("\narr1",arr1);
  vec1 = Arr::Vec(arr1);
  print("\nvec1 = Arr::Vec(arr1);",vec1);
  print("\nArr::VecRanges(arr1)",Arr::VecRanges(arr1));
  print("\nArr::VecLength(arr1) = ",Arr::VecLength(arr1));
  print("\nArr::UnVec(vec1,arr1)",Arr::UnVec(vec1,arr1));

  print("\nFunctions: Arr::Vecr, Arr::UnVecr\n");
  print("\narr1",arr1);
  vec1 = Arr::Vecr(arr1);
  print("\nvec1 = Arr::Vecr(arr1);",vec1);
  print("\nArr::UnVecr(vec1,arr1)",Arr::UnVecr(vec1,arr1));

  print("\nFunctions: Arr::SmartVec, Arr::SmartVecRanges, Arr::SmartVecLength, Arr::UnSmartVec\n");
  print("\narr1",arr1);
  vec1 = Arr::SmartVec(arr1);
  print("\nvec1 = Arr::SmartVec(arr1);",vec1);
  print("\nArr::SmartVecRanges(arr1)",Arr::SmartVecRanges(arr1));
  print("\nArr::SmartVecLength(arr1) = ",Arr::SmartVecLength(arr1));
  print("\nArr::UnSmartVec(vec1,arr1)",Arr::UnSmartVec(vec1,arr1));

  print("\nFunctions: Arr::SmartVecr, Arr::UnSmartVecr\n");
  print("\narr1",arr1);
  vec1 = Arr::SmartVecr(arr1);
  print("\nvec1 = Arr::SmartVecr(arr1);",vec1);
  print("\nArr::UnSmartVecr(vec1,arr1)",Arr::UnSmartVecr(vec1,arr1));

  arr2 = {{v,w},y};
  print("\nFunctions: Arr::Vcat, Arr::VcatRanges, Arr::VcatRows, Arr::UnVcat\n");
  print("\narr2",arr2);
  vec2 = Arr::Vcat(arr2);
  print("\nvec2 = Arr::Vcat(arr2);",vec2);
  print("\nArr::VcatRanges(arr2)",Arr::VcatRanges(arr2));
  print("\nArr::VcatRows(arr2) = ",Arr::VcatRows(arr2));
  print("\nArr::UnVcat(vec2,arr2)",Arr::UnVcat(vec2,arr2));

  arr3 = {s,w,{t,u}};
  print("\nFunctions: Arr::Hcat, Arr::HcatRanges, Arr::HcatColumns, Arr::UnHcat\n");
  print("\narr3",arr3);
  vec3 = Arr::Hcat(arr3);
  print("\nvec3 = Arr::Hcat(arr3);",vec3);
  print("\nArr::HcatRanges(arr3)",Arr::HcatRanges(arr3));
  print("\nArr::HcatColumns(arr3) = ",Arr::HcatColumns(arr3));
  print("\nArr::UnHcat(vec3,arr3)",Arr::UnHcat(vec3,arr3));

  print("\nFunctions: Arr::Diag\n");
  print("\nArr::Diag(arr3)",Arr::Diag(arr3));

  print("\nFunctions: Arr::ApplyFunc\n");
  print("\nArr::ApplyFunc(arr3,transpose);",Arr::ApplyFunc(arr3,transpose));

  arr4 = {s,{2*y,y}};
  print("\nFunctions: Arr::SumLogDet\n");
  print("\narr4",arr4);
  print("\nArr::SumLogDet(arr4) = ",Arr::SumLogDet(arr4));

}

