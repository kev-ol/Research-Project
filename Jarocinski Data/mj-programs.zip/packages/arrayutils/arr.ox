/* Arr class: function definitions */
Arr::GetVer()
{
  return 1;
}

Arr::recursively_apply_and_cumulate(const am, const funcappl, const funccumul)
/* recursively apply funcappl and cumulate with the results obtained so far with funccumul */
{
  decl result, carrsize, i;
  if (isarray(am))
    {
      result = recursively_apply_and_cumulate(am[0],funcappl,funccumul);
      carrsize = sizeof(am);
      for (i=1;i<carrsize;i++)
        {
          result = funccumul(result,recursively_apply_and_cumulate(am[i],funcappl,funccumul));
        }
      return result;
    }
  else
    {
      if (ismatrix(am))
        return funcappl(am);
      else
        oxrunerror("Element is neither a matrix nor an array!");
    }
}

Arr::recursively_unpack(const adstore, const adcurpos, const example, const funcunpackone)
{
  decl result, carrsize, i;
  if (isarray(example))
    {
      carrsize = sizeof(example);
      result = new array[carrsize];
      for (i=0;i<carrsize;i++)
        {
          result[i] = recursively_unpack(adstore,adcurpos,example[i],funcunpackone);
        }
      return result;
    }
  if (ismatrix(example))
    return funcunpackone(adstore,adcurpos,example);
  else
    oxrunerror("Element of the example array is neither a matrix nor an array!");
}

Arr::recursively_apply(const am, const func)
{
  decl result, carrsize, i;
  if (isarray(am))
    {
      carrsize = sizeof(am);
      result = new array[carrsize];
      for (i=0;i<carrsize;i++)
        {
          result[i] = recursively_apply(am[i],func);
        }
      return result;
    }
  if (ismatrix(am))
    return func(am);
  else
    oxrunerror("Element of the operand array is neither a matrix nor an array!");
}

  /* functions that unpack one element from the store */
Arr::unvec_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = sizerc(example);
  adcurpos[0] += cursize;
  return mj::Shape(adstore[0][cstart:cstart+cursize-1],rows(matrix(example)),columns(matrix(example)));
}
Arr::unvecr_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = sizerc(example);
  adcurpos[0] += cursize;
  return mj::Reshape(adstore[0][cstart:cstart+cursize-1],rows(matrix(example)),columns(matrix(example)));
}
Arr::unvech_one(const adstore, const adcurpos, const example)
{
  decl cstart,r,cursize;
  cstart = adcurpos[0];
  r = rows(matrix(example));
  cursize = r*(r+1)/2;
  adcurpos[0] += cursize;
  return unvech(adstore[0][cstart:cstart+cursize-1]);
}
Arr::unsmartvec_one(const adstore, const adcurpos, const example)
{
  if (sizerc(example)>1 && mj::IsSqSym(example))
    return unvech_one(adstore,adcurpos,example);
  else
    return unvec_one(adstore,adcurpos,example);
}
Arr::unsmartvecr_one(const adstore, const adcurpos, const example)
{
  if (sizerc(example)>1 && mj::IsSqSym(example))
    return unvech_one(adstore,adcurpos,example);
  else
    return unvecr_one(adstore,adcurpos,example);
}
Arr::unvcat_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = rows(matrix(example));
  adcurpos[0] += cursize;
  return adstore[0][cstart:cstart+cursize-1][];
}
Arr::unhcat_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = columns(matrix(example));
  adcurpos[0] += cursize;
  return adstore[0][][cstart:cstart+cursize-1];
}
Arr::vecrange_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = sizerc(example);
  adcurpos[0] += cursize;
  return range(cstart,cstart+cursize-1);
}
Arr::smartvecrange_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = Arr::smartsizerc(example);
  adcurpos[0] += cursize;
  return range(cstart,cstart+cursize-1);
}
Arr::vcatrange_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = rows(matrix(example));
  adcurpos[0] += cursize;
  return range(cstart,cstart+cursize-1);
}
Arr::hcatrange_one(const adstore, const adcurpos, const example)
{
  decl cstart,cursize;
  cstart = adcurpos[0];
  cursize = columns(matrix(example));
  adcurpos[0] += cursize;
  return range(cstart,cstart+cursize-1);
}

  /* cumulation */
Arr::vcat(const m1, const m2)
{
  if (columns(m1)==columns(m2))
    return m1|m2;
  else
  {
    print(m1); print(m2);
    oxrunerror("Attempt to vertically concatenate matrices with unequal number of columns!");
  }
}
Arr::hcat(const m1, const m2)
{
  if (rows(m1)==rows(m2))
    return m1~m2;
  else
    oxrunerror("Attempt to horizontally concatenate matrices with unequal number of rows!");
}

Arr::sum(const a, const b)
{
  return a+b;
}
  
  /* smart functions */
Arr::smartsizerc(const m)
{
  decl r;
  if (mj::IsSqSym(m))
    {
      r = rows(m);
      return r*(r+1)/2;
    }
  else
    return sizerc(m);
}
  
Arr::smartvec(const m)
{
  if (mj::IsSqSym(m))
    {
      return vech(m);
    }
  else
    return vec(m);
}

Arr::smartvecr(const m)
{
  if (mj::IsSqSym(m))
    {
      return vech(m);
    }
  else
    return vecr(m);
}
  
  /* other */
Arr::identity(const a)
{
  return a;
}

  /* end-user interfaces */
Arr::Vec(const am)
{
  return recursively_apply_and_cumulate(am,vec,Arr::vcat);
}
Arr::Vecr(const am)
{
  return recursively_apply_and_cumulate(am,vecr,Arr::vcat);
}
Arr::SmartVec(const am)
{
  return recursively_apply_and_cumulate(am,Arr::smartvec,Arr::vcat);
}
Arr::SmartVecr(const am)
{
  return recursively_apply_and_cumulate(am,Arr::smartvecr,Arr::vcat);
}
Arr::Vcat(const am)
{
  return recursively_apply_and_cumulate(am,Arr::identity,Arr::vcat);
}
Arr::Hcat(const am)
{
  return recursively_apply_and_cumulate(am,Arr::identity,Arr::hcat);
}
  
Arr::UnVec(const va, const amExample)
{
  decl curpos,store;
  if (VecLength(amExample)!=sizerc(va))
    oxrunerror("Vector and example don't match!");
  store = va;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unvec_one);
}
Arr::UnVecr(const va, const amExample)
{
  decl curpos,store;
  if (VecLength(amExample)!=sizerc(va))
    oxrunerror("Vector and example don't match!");
  store = va;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unvecr_one);
}

Arr::UnSmartVec(const va, const amExample)
{
  decl curpos,store;
  if (SmartVecLength(amExample)!=sizerc(va))
    oxrunerror("Vector and example don't match!");
  store = va;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unsmartvec_one);
}
Arr::UnSmartVecr(const va, const amExample)
{
  decl curpos,store;
  if (SmartVecLength(amExample)!=sizerc(va))
    oxrunerror("Vector and example don't match!");
  store = va;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unsmartvecr_one);
}
Arr::UnVcat(const ma, const amExample)
{
  decl curpos,store;
  if (VcatRows(amExample)!=rows(ma))
    oxrunerror("Vector and example don't match!");
  store = ma;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unvcat_one);
}
Arr::UnHcat(const ma, const amExample)
{
  decl curpos,store;
  if (HcatColumns(amExample)!=columns(ma))
    oxrunerror("Vector and example don't match!");
  store = ma;
  curpos = 0;
  return Arr::recursively_unpack(&store, &curpos, amExample, Arr::unhcat_one);
}
  
Arr::VecRanges(const am)
{
  decl curpos,dummystore;
  curpos = 0;
  return Arr::recursively_unpack(&dummystore, &curpos, am, Arr::vecrange_one);
}
Arr::SmartVecRanges(const am)
{
  decl curpos,dummystore;
  curpos = 0;
  return Arr::recursively_unpack(&dummystore, &curpos, am, Arr::smartvecrange_one);
}
Arr::VcatRanges(const am)
{
  decl curpos,dummystore;
  curpos = 0;
  return Arr::recursively_unpack(&dummystore, &curpos, am, Arr::vcatrange_one);
}
Arr::HcatRanges(const am)
{
  decl curpos,dummystore;
  curpos = 0;
  return Arr::recursively_unpack(&dummystore, &curpos, am, Arr::hcatrange_one);
}

Arr::VecLength(const am)
{
  return recursively_apply_and_cumulate(am,sizerc,Arr::sum);
}
Arr::SmartVecLength(const am)
{
  return recursively_apply_and_cumulate(am,Arr::smartsizerc,Arr::sum);
}
Arr::HcatColumns(const am)
{
  return recursively_apply_and_cumulate(am,columns,Arr::sum);
}
Arr::VcatRows(const am)
{
  return recursively_apply_and_cumulate(am,rows,Arr::sum);
}
  
Arr::Diag(const am)
{
  return recursively_apply_and_cumulate(am,Arr::identity,diagcat);
}

Arr::ApplyFunc(const am, const func)
{
  if (!isarray(am) && !ismatrix(am))
    oxrunerror("First argument is neither array nor matrix!\nUsage: Arr::ApplyFunc( array , func )");
  return recursively_apply(am,func);
}


/*
Ar::IsEq(const am1, const am2)
{
  decl size, i;
  size = sizeof(am1);
  if (size!=sizeof(am2)) return FALSE;
  for (i=0; i<size; i++)
    {
      if (!iseq(am1[i],am2[i])) return FALSE;
    }
  return TRUE;
}
*/

  /* LogDet */
Arr::logdetnosign(const ma)
{
  decl dsign, result;
  result = logdet(ma,&dsign);
  if (dsign==1)
    return result;
  else
    oxrunerror(sprint("Careful with logdet: the sign of the determinant has code ",dsign,"!"));
}

Arr::SumLogDet(const am)
{
  return recursively_apply_and_cumulate(am,Arr::logdetnosign,Arr::sum);
}


Arr::SymmetricTree(const viStructure, const leaf) /* build a symmetric nested array */
{
  decl tree, branch, i, j;
  branch = leaf;
  for (i=sizerc(viStructure)-1;i>=0;i--)
    {
      tree = new array[int(viStructure[i])];
      for (j=0;j<viStructure[i];j++)
        tree[j]=branch;
      branch = tree;
    }
  return tree;
}