/* Ar class: function definitions */

Ar::Vecr(const am)
{
  decl bigvector, celem;
  
  bigvector = <>;
    
  for ( celem=0; celem<sizeof(am) ; celem++ )
  {
    if ( mj::IsSqSym(am[celem]) )
    {
      bigvector ~= vech(matrix(am[celem]))';
    }
    else
    {
      bigvector ~= vecr(am[celem])';
    }
  }
  return bigvector;
}

Ar::Unvecr(const va, const amExample)
{
  decl i, aranges, am;
  if (VecLength(amExample)!=sizerc(va)) oxrunerror("Vector and Example array don't match!",0);
  aranges = VecRanges(amExample);
  am = new array[sizeof(amExample)];
  for (i=0; i<sizeof(am); i++)
    {
      if (mj::IsSqSym(amExample[i])) am[i] = unvech(matrix(va[aranges[i]])); //vech bug!!!
      else am[i] = mj::Reshape(va[aranges[i]],rows(amExample[i]),columns(amExample[i]));
    }
  return am;
}


Ar::VecLength(const am)
{
  decl celem, length;
  length = 0;
  for (celem=0; celem<sizeof(am); celem++)
  {
    length += MatrixVecLength(am[celem]);
  }
  return length;
}

Ar::MatrixVecLength(const ma)
{
  decl mat;
  mat = matrix(ma);

  decl r;
  r = rows(mat);
  if ( mj::IsSqSym(mat) )
  {
    return r*(r+1)/2;
  }
  else
  {
    return r*columns(mat);
  }
}

Ar::calculateranges(const am, const func)
{
  decl aranges, begin, end, celem;
  aranges = new array[0];
  begin = 0;
  for (celem=0; celem<sizeof(am); celem++)
  {
    end = begin + func(am[celem]);
    aranges ~= range(begin,end-1);
    begin = end;
  }
  return aranges;
}

Ar::VecRanges(const am)
{
  return calculateranges(am, MatrixVecLength);
}

Ar::VcatRanges(const am)
{
  return calculateranges(am, rows);
}

Ar::HcatRanges(const am)
{
  return calculateranges(am, columns);
}

Ar::Vcat(const am)
{
  decl vconcat, cols, celem;
  
  vconcat = am[0];
  cols = columns(vconcat);
      
  for ( celem=1; celem<sizeof(am) ; celem++ )
  {
    if ( columns(am[celem])==cols ) vconcat |= am[celem];
    else oxrunerror("Attempt to stack matrices with unequal number of columns!",0);
  }
  return vconcat;
}

Ar::Hcat(const am)
{
  decl hconcat, crows, celem;
  
  hconcat = am[0];
  crows = rows(hconcat);
      
  for ( celem=1; celem<sizeof(am) ; celem++ )
  {
    if ( rows(am[celem])==crows ) hconcat ~= am[celem];
    else oxrunerror("Attempt to Hconcat matrices with unequal number of rows!",0);
  }
  return hconcat;
}

Ar::Diag(const am)
{
  decl diag, celem;
  diag = am[0];
  for ( celem=1; celem<sizeof(am) ; celem++ )
  {
    diag = diagcat(diag,am[celem]);
  }
  return diag;
}

Ar::IsEq(const am1, const am2)
{
  decl size, i;
  size = sizeof(am1);
  if (size!=sizeof(am2)) return FALSE;
  for (i=0; i<size; i++)
    {
      if (!iseq(am1[i],am2[i])) return FALSE;
    }
  return TRUE;
}

Ar::Sum(const am)
{
  decl i, ret;
  ret = am[0];
  for (i=1;i<sizeof(am);i++)
    {
      if( rows(am[i])==rows(ret) && columns(am[i])==columns(ret) )
        ret += am[i];
      else
        oxrunerror("Can't add matrices with different sizes!");          
    }
  return ret;
}

Ar::Mean(const am)
{
  return Ar::Sum(am)/sizeof(am);
}
  
Ar::SumLogDet(const am)
{
  decl i, sign, sumlogdet;
  sumlogdet = 0;
  for (i=0;i<sizeof(am);i++)
    {
      sumlogdet += logdet(am[i],&sign);
    }
  return sumlogdet;
}

Ar::ApplyFunc(const am, const func, ...)
{
  decl size,i,aret, args = va_arglist();
  size = sizeof(am);
  aret = new array[size];
  if (sizeof(args)==0)
    {
      for (i=0;i<size;i++)
        {
          aret[i]=func(am[i]);
        }
    }
  if (sizeof(args)==1)
    {
      for (i=0;i<size;i++)
        {
          aret[i]=func(am[i],args[0]);
        }
    }
  if (sizeof(args)==2)
    {
      for (i=0;i<size;i++)
        {
          aret[i]=func(am[i],args[0],args[1]);
        }
    }
  if (sizeof(args)==3)
    {
      for (i=0;i<size;i++)
        {
          aret[i]=func(am[i],args[0],args[1],args[2]);
        }
    }
  if (sizeof(args)==4)
    {
      for (i=0;i<size;i++)
        {
          aret[i]=func(am[i],args[0],args[1],args[2],args[3]);
        }
    }
    
  return aret;
}
