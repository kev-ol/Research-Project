#ifndef ARR_INCLUDED
#define ARR_INCLUDED

#import "packages/mj/mj"
#include "packages/mj/operators.ox"


class Arr
{
  static GetVer();
  
  /* recursive functions */
  static recursively_apply(const am, const func);
  static recursively_apply_and_cumulate(const am, const funcappl, const funccumul);
  static recursively_unpack(const adstore, const adcurpos, const example, const funcunpackone);

  /* functions that unpack one element from the store */
  static unvec_one(const adstore, const adcurpos, const example);
  static unvecr_one(const adstore, const adcurpos, const example);
  static unvech_one(const adstore, const adcurpos, const example);
  static unsmartvec_one(const adstore, const adcurpos, const example);
  static unsmartvecr_one(const adstore, const adcurpos, const example);
  static unvcat_one(const adstore, const adcurpos, const example);
  static unhcat_one(const adstore, const adcurpos, const example);

  static vecrange_one(const adstore, const adcurpos, const example);
  static smartvecrange_one(const adstore, const adcurpos, const example);
  static vcatrange_one(const adstore, const adcurpos, const example);
  static hcatrange_one(const adstore, const adcurpos, const example);


  /* cumulation */
  static vcat(const m1, const m2);
  static hcat(const m1, const m2);
  static sum(const a, const b);
  
  /* smart functions */
  static smartsizerc(const m);
  static smartvec(const m);
  static smartvecr(const m);
  
  /* other */
  static identity(const m);
  
  /* end-user interfaces */
  static Vec(const am);
  static Vecr(const am);
  static SmartVec(const am);
  static SmartVecr(const am);
  static Vcat(const am);
  static Hcat(const am);
  
  static UnVec(const va, const amExample);
  static UnVecr(const va, const amExample);
  static UnSmartVec(const va, const amExample);
  static UnSmartVecr(const va, const amExample);
  static UnVcat(const ma, const amExample);
  static UnHcat(const ma, const amExample);
  
  static VecRanges(const am);
  static SmartVecRanges(const am);
  static VcatRanges(const am);
  static HcatRanges(const am);

  static VecLength(const am);
  static SmartVecLength(const am);
  static VcatRows(const am);
  static HcatColumns(const am);
  
  static Diag(const am);
  
  static ApplyFunc(const am, const func);
   
/*  static IsEq(const am1, const am2); */
  
  /* SumLogDet */
  static logdetnosign(const ma);
  static SumLogDet(const am);
  
  static SymmetricTree(const viStructure, const leaf);  
};

#endif /* ARR_INCLUDED */
