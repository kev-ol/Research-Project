#include <oxstd.h>

#import "ar"

main()
{
  decl t,u,v,w,x,y,z;
  decl aA,aB,aC;

  u = matrix(1);
  v = constant(3,2,2);
  w = constant(4,2,2);
  x = ones(3,2);
  y = unit(2);
  z = <1,2;3,4;5,6>;

  aA = { {u,v,w},x,y,z};
  print(aA);

//  print(Ar::Vecr(a));
//  print(Ar::Vconcat(a));
//  print(Ar::VecRanges(a));
//  print(Ar::Diag(a));

  print(Ar::recursively_apply_and_vcat(aA,vec));  

//  decl v;
//  v = Ar::Vecr(a)';
//  print(v);
//  print(Ar::Unvecr(v,a));
}
