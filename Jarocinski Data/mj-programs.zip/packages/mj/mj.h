#ifndef MJ_INCLUDED
#define MJ_INCLUDED

#include <oxprob.h>
#include "operators.ox"
#import <database>

class mj
{
  static GetVer();

  static IsSqSym(const ma);
  static CholeskiEps(const mSig);
  static LogDet(const mS);
  
  /* safe/enhanced versions of ox functions */
  static Shape(const ma, const crows, const ccols);
  static Reshape(const ma, const crows, const ccols);
  static Choleski(const ma);
  static Selectifrc(const ma, const mifr, const mifc);
  static minr(const mA);
  static maxr(const mA);
  
  /* printout */
  static PrintDimensions(const ma);
  static ReportChi2(const dchi2, const idf);
  static ReportF(const dF, const idfnum, const idfden); 
  
  /* array/matrix/strings conversion */
  static split(const str, const sep); // like python str.split
  static s2as(const str);
  static as2s(const as, ...); // optionally supply a connector string
  static mat2str(const ma, ...);
  static asDif(const asFirst, const asSecond);
  static strDif(const sFirst, const sSecond);
  
  /* special matrix creation */
  static Rotation(const idim, const ij, const ik, const dangle);
  static Commutation(const in, const im);
  static Duplication(const in);
  static P(const mX);
  static M(const mX);
  static M1(const idim);
  static SymMatrixPower(const ms, const exponent);
  static VechCoordinates(const cDim);
  static DiagonalInVechCoordinates(const cDim);
  static asPairs(const asNames, ...);
  static ranks(const vX); // replace by rankingc(const mX);
  
  /* statistical */
  static Var2Cor(const mvar);
  static RanIWishart(const mS_chol, const cdegf);
  static ranIWishart_std_chol(const q, const v);

  /* binary <-> decimal conversion */
  static bin2dec(const vbinary);
  static dec2bin(const idecimal);

  /* Database class utilities */
  /* sample */
  static LagDate(const iYear, const iPeriod, const iFreq, const iLags);
  static LagSample(const ssample, const cfreq, const clags);
  static ScanSampleText(const ssample);
  static SampleSize(const ssample, const iFreq);
  /* selectors */
  static MakeDefaultDatabaseSelector(const asSeriesNames,...);
  static DbSel2Text(const aSel); // converts a Database selector into an info text on the selection
  static NamesInSel(const aSel); // returns an array of strings with variable names in the selection
  static SelLength(const aSel); // number of variables selected
  static LagSelector(const aSel, const iLags);
  /* other */
  static CheckForVars(const asVarList, const Dbase);
  static DbMerge(const adbs, const iMsgLevel);
  static DbMergeFromFiles(const asFiles, const iMsgLevel);
  
  /* Checking the operating system */
  static Unix();
  static Windows();
  
  /* other */
  static RanseedCurTime();
  static path2fname(const sPath);
  static Time(...);
  static TimeStamp(...);
  static RenameDirectory(const sNameBefore, const sNameAfter);
  static savetext(const sfname, const stext);
  static loadtext(const sfname);
};

#endif /* MJ_INCLUDED */
