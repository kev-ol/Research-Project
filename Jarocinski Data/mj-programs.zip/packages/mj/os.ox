
os::Unix()
{
  if (sizeof(getenv("PWD"))>0) return TRUE;
  else return FALSE;
}
os::Windows()
{
  if (getenv("PWD")=="") return TRUE;
  else return FALSE;
}

os::winslash(const str) //converts unix path to windows slashes
{
  decl ind = strfind(str, '/'), ret = str;
  while (ind>-1)
    {
      //println("where found: ",ind);
      ret = (ind>0 ? ret[0:ind-1] : "")~"\\"~(ind+1<sizerc(ret) ? ret[ind+1:] : "");
      ind = strfind(ret, '/');
    }
  return ret;
}

os::rename(const sSrc, const sDst)
{
  println("renaming ",sSrc," to ",sDst);
  //fclose("l");  // close log, otherwise sNameBefore/ is locked
  if (os::Unix())
    systemcall(sprint("mv ",sSrc," ",sDst));
  else
    systemcall(sprint("rename ",winslash(sSrc)," ",winslash(sDst)));
}

os::mkdir(const sPath)
{
  systemcall(sprint("mkdir ",sPath));
}

os::rmdir(const sPath)
{
  systemcall(sprint("rmdir ",sPath));
}

os::touch(const sfile)
{
  if (os::Unix())
    systemcall(sprint("touch ",sfile));
  else
    systemcall(sprint("echo on > ",sfile));
}

os::mv(const src, const dst)
{
  if (os::Unix())
    systemcall(sprint("mv ",src," ",dst));
  else
    systemcall(sprint("move ",src," ",dst));
}

os::copy(const src, const dst)
{
  if (os::Unix())
    systemcall(sprint("cp ",src," ",dst));
  else
    systemcall(sprint("copy ",winslash(src)," ",winslash(dst)));
}

os::getpwd(const idepth)
{
  decl spwd = getcwd();
  decl ind = sizeof(spwd);
  decl sslash;
  if (os::Unix()) sslash = "/";
  else sslash = "\\";
  for (decl i=0;i<idepth;i++)
    {
      ind = strfindr(spwd[0:ind-1],sslash);
    }
  return spwd[ind+1:];
}

os::listdir(const sPath)
{
  decl sTempFile = "listdir.txt";
  if (os::Unix())
    systemcall(sprint("ls ",sPath," > ",sTempFile));
  else
    systemcall(sprint("dir ",sPath," /B > ",sTempFile));
  
  decl asResult = new array[0];
  decl s;
  decl f = fopen(sTempFile,"r");
  decl c = fscan(f,"%s",&s);  
  while (c==1)
    {
      asResult ~= s;
      c = fscan(f,"%s",&s);
    }
  fclose(f);
  fremove(sTempFile);
  return asResult;
}