#ifndef MJ_OS_INCLUDED
#define MJ_OS_INCLUDED

class os
{
  static Unix();
  static Windows();
  
  static winslash(const sPath);
  
  static rename(const sSrc, const sDst);
  static mkdir(const sPath);
  static rmdir(const sPath);
  static touch(const sfile);
  static mv(const src, const dst);
  static copy(const src, const dst);

  static getpwd(const idepth);
  static listdir(const sPath);
};

#endif /* MJ_OS_INCLUDED */
