#ifndef OPERATORS_INCLUDED
#define OPERATORS_INCLUDED

sum(const a, const b)
{
  return a+b;
}

prod(const ma, const mb)
{
  return ma*mb;
}

kronprod(const ma, const mb)
{
  return ma**mb;
}

transpose(const ma)
{
  return ma';
}

inner(const ma)
{
  return ma'ma;
}

identity(const a)
{
  return a;
}

#endif /* OPERATORS_INCLUDED */