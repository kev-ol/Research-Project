#include <oxstd.h>
#import "packages/mj/mj"
#import "packages/mj/os"

main()
{
  decl mA = toeplitz(<1,-1>,4);
  
  print(mA);
}