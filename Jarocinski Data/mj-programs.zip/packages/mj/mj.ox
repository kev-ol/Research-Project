/*
** various utilities
** Marek Jarocinski 
*/

mj::GetVer()
{
  return "2008-03-01";
}

mj::IsSqSym(const ma)
{
  if ( rows(ma)==columns(ma) && iseq(vech(ma),vech(ma')) ) return TRUE;
  else return FALSE;
}

mj::LogDet(const mS)
{
  decl ret, asign;
  ret = logdet(mS,&asign);
  if (asign != 1) oxrunerror("Matrix not positive definite!");
  else return ret;
}

/* safe/enhanced versions of ox functions */

mj::Shape(const ma, const crows, const ccols)
{
  if ( sizerc(ma) != crows*ccols )
     {
      oxrunerror("mj::Shape error: rows*columns don't match!",1);
     }
  if ( crows != int(crows) )
     {
      oxrunerror("mj::Shape error: 'rows' are not integer!",1);
     }
  if ( ccols != int(ccols) )
     {
      oxrunerror("mj::Shape error: 'columns' are not integer!",1);
     }
  return shape(ma, crows, ccols);
}

mj::Reshape(const ma, const crows, const ccols)
{
  if ( sizerc(ma) != crows*ccols )
    {
      oxrunerror("mj::Reshape error: rows*columns don't match!",1);
    }
  if ( crows != int(crows) )
    {
      oxrunerror("mj::Reshape error: 'rows' are not integer!",1);
    }
  if ( ccols != int(ccols) )
    {
      oxrunerror("mj::Reshape error: 'columns' are not integer!",1);
    }
  return reshape(ma, crows, ccols);
}

mj::Choleski(const ma)
{
  decl chol;
  chol = choleski(ma);
  if ( chol==0 ) { oxrunerror("Safe Choleski halts the program!",1); }
  return chol;
}

mj::CholeskiEps(const mSig)
{
  decl storedfuz, curfuz, maxfuz = 1e-4;
  decl c = columns(mSig), sel, p, psel;

  storedfuz = fuzziness(-1);
  curfuz = storedfuz;
  psel=0;

  while (columns(psel)==0 && curfuz<=maxfuz)
    {
      sel = vecindex(!isdotfeq(diagonal(mSig),0));
      psel = choleski(mSig[sel][sel]);
      curfuz *= 10;
      fuzziness(curfuz);
    }
  
  fuzziness(storedfuz);

  if (curfuz>maxfuz && columns(sel)>0) { print("Matrix not pos-def or check the CholeskiEps!"); return 0;}

  p = zeros(c, c);
  p[sel][sel] = psel;
  return p;
}

mj::Selectifrc(const ma, const mifr, const mifc)
{
  return selectifc(selectifr(ma,mifr),mifc);
}
mj::minr(const mA)
{
  return minc(mA')';
}
mj::maxr(const mA)
{
  return maxc(mA')';
}

/* printout */

mj::PrintDimensions(const ma)
{
  println("rows: ", rows(ma), ", cols: ",columns(ma));
}

mj::ReportChi2(const dchi2, const idf)
{
  if (!isdouble(dchi2) && (rows(dchi2)!=1 || columns(dchi2)!=1) )
    {
      oxrunerror("The argument should be a double or a 1x1 matrix!");
    }
  return sprint("chi2(",idf,"): ",double(dchi2),", P-value: ",tailchi(double(dchi2),idf));
}

mj::ReportF(const dF, const idfnum, const idfden)
{
  return sprint("F(",idfnum,",",idfden,"): ",double(dF),", P-value: ",tailf(double(dF),idfnum,idfden));
}

/* array/matrix/strings conversion */

mj::split(const str, const sep)
/* split str using sep, return array of substrings
   consecutive seps are deemed to delimit empty strings
   (based on the python string method split) */
{
  decl workstr = str;
  decl sepsize = sizeof(sep);
  decl ipos;
  decl ret = new array[0];
  
  while (sizeof(workstr)>0)
    {
      ipos = strfind(workstr, sep);
      if (ipos<0)
	{
	  ret |= workstr;
	  break;
	}
      else
	{
	  ret |= ipos>0 ? workstr[0:ipos-1] : "" ;
          if ( sizeof(workstr)>(ipos+sepsize) )
             workstr = workstr[ipos+sepsize:];
          else { ret |= ""; workstr = ""; }
        }
    }
  return ret;
}

mj::s2as(const str)
{
  decl workstr,astr,scanresult,curstr;

  workstr = str;
  astr = new array[0];
  scanresult = 0;

  while (scanresult > -1)
  {
    scanresult = sscan(&workstr,"%s",&curstr);
    if (scanresult > -1) astr |= curstr;
  }
  return astr;
}

mj::as2s(const as, ...) // optionally supply a connector string
{
  decl aconnect = va_arglist(),sconnect,s,celem;
  if (isstring(as))
    return as;
  if (sizeof(aconnect)==0)
    sconnect = " "; // default connector
  else
    sconnect = aconnect[0];

  s = "";
  for (celem=0; celem<sizeof(as); celem++)
  {
    s = sprint(s,as[celem]);
    s ~= sconnect;
  }
  if (sizeof(s)>0) s = s[0:sizeof(s)-sizeof(sconnect)-1]; // truncate the last connector
  return s;
}

mj::mat2str(const ma,...)
/* convert a matrix to a string with values
** optional nonzero argument -> trim the spaces between elements
*/
{
  decl arg=va_arglist(),bPad,size, str, i;
  if (sizeof(arg)>0)
    {
      bPad = 0;
    }
  else
    {
      bPad = 1;
    }
  size = sizerc(ma);
  str = "";
  
  oxwarning(0);
  for (i=0;i<size;i++)
    {
      str ~= sprint(ma[i]);
      if( bPad )
        {
          str ~= " ";
        }
    }
  oxwarning(-1);
  
  if( bPad )
    {
      str = str[0:sizeof(str)-2]; // truncate the last space
    }
  return str;
}

mj::asDif(const asFirst, const asSecond)
/* from asFirst drop all strings that are found in asSecond */
{
  decl moverlap;
  moverlap = dropc(strfind(asFirst,asSecond),-1);
  return asFirst[dropc(range(0,sizeof(asFirst)-1),moverlap)];
}
mj::strDif(const sFirst, const sSecond)
{
  decl beg = strfind(sFirst,sSecond);
  if (beg<0) return "";
  else return sFirst[dropc(range(0,sizeof(sFirst)-1),range(beg,beg+sizeof(sSecond)-1))];
}

/* special matrix creation */

mj::Rotation(const idim, const ij, const ik, const dangle)
/*
** Creates matrix that rotates rows j and k
** of a square matrix (idim x idim) by the given angle
*/
{
  decl mrotation;
  mrotation = unit(idim);
  mrotation[ij][ij] = cos(dangle);
  mrotation[ik][ik] = cos(dangle);
  mrotation[ij][ik] = -sin(dangle);
  mrotation[ik][ij] = sin(dangle);
  return mrotation;
}

mj::Commutation(const in, const im)
// see Magnus and Neudecker 1988, p.
// Knm * vec(X') = vec(X)    where X is n x m
// from matlab code by Thomas P Minka (tpminka@media.mit.edu) 
// reshape(kron(vec(eye(n)), eye(m)), n*m, n*m);
{
  return shape( vec(unit(in))**unit(im), in*im, in*im);
}

mj::Duplication(const n) 
// see Magnus and Neudecker 1988, p.
// Dn * vech(X) = vec(X)      where X is n x n symmetric
// from matlab code by Thomas P Minka (tpminka@media.mit.edu) 
{
  decl a, k, i, j, r, mresult;
  
  a = zeros(n,n);
  k = 0;
  for (j=0;j<n;j++)
    for (i=0;i<n;i++)
      {
        if (i>=j)
          a[i][j]=k++;
        else
          a[i][j] = a[j][i];
      }
  a = vec(a);
  
  mresult = zeros(n^2,n*(n+1)/2);
  for (r=0;r<rows(mresult);r++)
    mresult[r][a[r]] = 1;
  return mresult;
}

mj::P(const mX)
/* returns matrix of projection on X -> X(X'X)"X */
{
  return outer(mX,invertsym(outer(mX,<>,"o")));
}

mj::M(const mX)
/* returns residual-from-projection-on-X maker */
{
  return unit(rows(mX))-P(mX);
}

mj::M1(const idim)
/*
** Creates idempotent square matrix M0=I-1/nii' that transforms n-vector to deviations from mean.
*/
{
  return unit(idim)-constant(1/idim,idim,idim);
}

mj::SymMatrixPower(const ms, const exponent)
{
  decl result, veigenval, meigenvec;

  result = eigensym(ms, &veigenval, &meigenvec);
  return outer(meigenvec,diag(veigenval.^exponent));
}

mj::VechCoordinates(const cDim)
{
  decl result, i;
  result = new matrix[0];
  
  for (i=0;i<cDim;i++)
    {
      result |= (range(i,cDim-1)')~constant(i,cDim-i,1);
    }
  return result;
}

mj::DiagonalInVechCoordinates(const cDim)
{
  decl result, i;
  result = zeros(cDim,1);
  for (i=1;i<cDim;i++)
    result[i] = sumr(range(cDim-i+1,cDim));
  return result;
}

mj::asPairs(const asNames, ...)
/*  in: asNames, array of strings;
** out: array of strings with all unique pairs of strings from asNames;
** optional arg: connector of pairs (default: space) */
{
  decl args = va_arglist(), sinterfix, mcoordinates, cresultsize, asresult, i;
  if (sizeof(arglist)==0)
    sinterfix = " ";
  else
    sinterfix = args[0];
  
  mcoordinates = mj::VechCoordinates(sizeof(asNames));
  cresultsize = rows(mcoordinates);
  
  asresult = new array[cresultsize];
  
  for (i=0;i<cresultsize;i++)
    {
      asresult[i] = sprint(asNames[mcoordinates[i][0]],sinterfix,asNames[mcoordinates[i][1]]);
    }
  return asresult;
}

mj::ranks(const vX)
{
  return sortcindex(sortcindex(vX));
}

/* statistical */

mj::Var2Cor(const mvar)
{
  return mvar.*diagonal(mvar).^-0.5.*diagonal(mvar)'.^-0.5;
}

mj::RanIWishart( const mS_chol, const cdegf)
/* draw from Inverted Wishart distribution, Bauwens, Lubrano, Richard (1999), App.B */
{
  decl W;
  W = ranIWishart_std_chol( rows(mS_chol), cdegf );
  return mS_chol*W*W'*mS_chol'; 
}

mj::ranIWishart_std_chol( const q, const v)
/*
** returns choleski factor of a IW(unit(q),v), v>q+1
** q - dimension; v - degrees of freedom
*/
{
  decl W, i, sw, e, WLT, z;
  
  W = zeros(q, q);
  
  for(i=q-1; i>=0; i-- )
     {
    sw = ranchi(1,1,v+i+1-q)^-0.5;
    W[i][i]=sw;
    if (i<q-1)
       {
      e = range(i+1,q-1);
      WLT = W[e][e];
      z = rann(q-i-1,1);
      W[e][i]=sw * WLT * z;
        }
      }

  return W;
}

/*** binary <-> decimal integer conversion ***/
/* -> binary numbers are stored as horizontal vectors of 0 and 1;
** -> sign of the decimal is ignored; 
** -> noninteger part of the decimal is ignored */

mj::bin2dec(const vbinary)
{
  if (vbinary==<0>) return 0;
  return int(sumc(2^vecindex(reversec(vec(vbinary)))));
}

mj::dec2bin(const idecimal)
{
  if (idecimal==0) return <0>;

  decl dec, bin;  
  dec = fabs(idecimal);  
  bin = <>; 
  while ( dec>=2 )
        {
          bin ~= imod(dec,2);
          dec = idiv(dec,2);
        }
  bin ~= 1;
  bin = reverser(bin);
  return bin;
}


/* Database class utilities */
/* sample */

mj::LagDate(const iYear, const iPeriod, const iFreq, const iLags)
{
  decl iIndex = iYear*iFreq+iPeriod-1-iLags;
  return {idiv(iIndex,iFreq), imod(iIndex,iFreq)+1};
}

mj::LagSample(const ssample, const cfreq, const clags)
/* Returns the effective sample after taking 'clags' lags */
{
  decl year1, period1, year2, period2, index1;
  [ year1, period1, year2, period2] = ScanSampleText(ssample);
  index1 = cfreq*year1+period1-1+clags;
  year1 = floor(index1/cfreq);
  period1 = imod(index1,cfreq)+1;
  return sprint(year1, " (", period1, ") - ", year2, " (", period2, ")" );
}

mj::ScanSampleText(const ssample)
{
  decl result, year1, period1, year2, period2;
  result = sscan(ssample, "%u", &year1, " (%u", &period1,
            ") - %u", &year2, " (%u", &period2);
  if (result < 4)
    {
      result = sscan(ssample, "%u", &year1, " - %u", &year2);
      if (result < 2) oxrunerror("This does not look like a database sample string!!!");
      else period1 = period2 = 1;
    }
  
  return {year1, period1, year2, period2 };
}

mj::SampleSize(const ssample, const iFreq)
{
  decl year1, period1, year2, period2;
  [  year1, period1, year2, period2 ] = mj::ScanSampleText(ssample);
  return (year2 - year1) * iFreq + period2 - period1 + 1;
}

/* selectors */

mj::MakeDefaultDatabaseSelector(const asSeriesNames, ...)
/* 'Default' means that there are no lagged variables */
/* 14-10-03: now a common number of lags allowed */
{
  decl args = va_arglist(),cminlag,cmaxlag;
  decl cseries, aSel;
  if (sizeof(args)>0)
    {
      cminlag = args[0];
      cmaxlag = args[1];
    }
  else
    {
      cminlag = cmaxlag = 0;
    }
  
  aSel = new array[0];
  for ( cseries=0; cseries<sizeof(asSeriesNames); cseries++ )
    {
      aSel ~= asSeriesNames[cseries]; aSel ~= {cminlag,cmaxlag};
    }
  return aSel;
}

mj::DbSel2Text(const aSel)
{
  decl stext, i;
  stext = "";
  for (i=0;i<sizeof(aSel);i+=3)
    {
      stext ~= sprint(aSel[i],aSel[i+1],"_",aSel[i+2],",");
    }
  if (sizeof(aSel)>0) stext = stext[0:sizeof(stext)-2];
  return stext;
}

mj::NamesInSel(const aSel)
/* returns an array of strings with variable names in the selection */
{
  decl asNames, i;
  asNames = new array[0];
  for (i=0;i<sizeof(aSel);i+=3)
    {
      asNames |= aSel[i];
    }
  return asNames;
}

mj::SelLength(const aSel)
{
  decl i, result = 0;
  for (i=0;i<sizeof(aSel);i+=3)
    {
      result += aSel[i+2]-aSel[i+1]+1;
    }
  return result;
}

mj::LagSelector(const aSel, const iLags)
{
  decl i, aSelLagged = new array[sizeof(aSel)];
  for (i=0;i<sizeof(aSel);i+=3)
    {
      aSelLagged[i] = aSel[i];
      aSelLagged[i+1] = aSel[i+1]+iLags;
      aSelLagged[i+2] = aSel[i+2]+iLags;
    }
  return aSelLagged;
}


/* other */
mj::CheckForVars(const asVarList, const Dbase)
{
  decl i, carg;
  carg = sizeof(asVarList);
  for (i = 0; i < carg; i++)
  {
    if (strfind(Dbase.GetAllNames(), asVarList[i])==-1)
      oxrunerror(sprint("Variable ",asVarList[i]," not found in the database!"),1);
  }
}

#include "dbmerge.ox"

/* Checking the operating system */
mj::Unix()
{
  if (sizeof(getenv("HOSTNAME"))>0) return TRUE;
  else return FALSE;
}
mj::Windows()
{
  if (getenv("OS")=="Windows_NT") return TRUE;
  else return FALSE;
}

/* seed random number generator with the current time */
mj::RanseedCurTime()
{ ranseed(today()-1045e6); }


mj::path2fname(const sPath)
/* will crash if there is no extension! */
{
  decl ilastslash, idot;
  ilastslash = strfindr(sPath,"/");
  if (ilastslash == -1) ilastslash = strfindr(sPath,"\\");
  idot = strfindr(sPath,".");
  if (idot == -1) { idot = sizeof(sPath)-1; print(idot);}
  return (sPath[ilastslash+1:idot-1]);
}

mj::Time(...) // not nice, convert to TimeStamp() instead!
{
  decl stime = time(), args = va_arglist(), sconnector;
  if (sizeof(args)>0)
    sconnector = args[0];
  else
    sconnector = "";
  if (strfind(stime," ")>-1) stime=sprint("0",stime[1:]);
  return sprint(stime[0:1],sconnector,stime[3:4],sconnector,stime[6:7]);
}

mj::TimeStamp(...)
{
  decl args = va_arglist(), iprecision, sconnector, mtime, i, stimestamp;
  
  if (sizeof(args)>0)
    iprecision = int(args[0]);
  else
    iprecision = 3;
  if (iprecision>6) iprecision=6;
  
  
  if (sizeof(args)>1)
    sconnector = string(args[1]);
  else
    sconnector = "";
  
  mtime = timing(today(),1);  
  stimestamp = sprint("%02i",mtime[0]-2000);
  
  for (i=1;i<iprecision;i++)
    {
      stimestamp ~= sprint(sconnector,"%02i",mtime[i]);
    }
  return stimestamp;
}


mj::RenameDirectory(const sNameBefore, const sNameAfter)
{
  println("renaming ",sNameBefore," to ",sNameAfter);
  fclose("l");  // close log, otherwise sNameBefore/ is locked
  if (mj::Unix())
    systemcall(sprint("mv ",sNameBefore," ",sNameAfter));
  else
    systemcall(sprint("rename ",sNameBefore," ",sNameAfter));
}

mj::savetext(const sfname, const stext)
{
  decl outfile = fopen(sfname,"w");
  fprint(outfile,stext);
  fclose(outfile);
}

mj::loadtext(const sfname)
{
  decl stext, infile = fopen(sfname);
  if (!isfile(infile)) oxrunerror(sprint("File ",sfname," not found!"));
  fscan(infile,sprint("%",fsize(infile),"c"),&stext);
  fclose(infile);;
  return stext;
}