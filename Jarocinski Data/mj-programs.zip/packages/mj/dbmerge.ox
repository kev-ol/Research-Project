
mj::DbMerge(const adbs, const iMsgLevel)
{
  decl dbmerged;
  decl iFreq, iYear1, iPeriod1, iYear2, iPeriod2;
  decl cdbs = sizeof(adbs);
  decl i;
  decl vStarts;
  decl vEnds;
  decl mdata,istart,iend;

  /* determine start and end of the merged database */  
  vStarts = vEnds = zeros(cdbs,1);
  iFreq = adbs[0].GetFrequency();
  for (i=0;i<cdbs;i++)
    {
      if (adbs[i].GetFrequency() != iFreq) oxrunerror(sprint("DbMerge: common frequency ",iFreq,"; database ",i," has frequency ",adbs[i].GetFrequency(),"!"));
      vStarts[i] = adbs[i].GetYear1()*iFreq + adbs[i].GetPeriod1();
      vEnds[i] = adbs[i].GetYear2()*iFreq + adbs[i].GetPeriod2();
    }
  if (maxc(vStarts)>minc(vEnds)) oxrunerror("DbMerge: database samples don't overlap!");
  
  iYear1 = adbs[maxcindex(vStarts)].GetYear1();
  iPeriod1 = adbs[maxcindex(vStarts)].GetPeriod1();

  iYear2 = adbs[mincindex(vEnds)].GetYear2();
  iPeriod2 = adbs[mincindex(vEnds)].GetPeriod2();

  /* create and fill merged database */
  dbmerged = new Database();
  dbmerged.Create(iFreq,iYear1,iPeriod1,iYear2,iPeriod2);
  print("Merging databases. Size of the resulting database: ",dbmerged.GetSize()," observations\n");

  for (i=0;i<cdbs;i++)
    {
      mdata = adbs[i].GetAll();
      istart = adbs[i].GetIndex(iYear1,iPeriod1);
      iend = adbs[i].GetIndex(iYear2,iPeriod2);
      if (iMsgLevel>1) print("adding variables ",adbs[i].GetAllNames(),"\n");
      dbmerged.Append(mdata[istart:iend][],adbs[i].GetAllNames());
    }
  
  return dbmerged;
}

mj::DbMergeFromFiles(const asFiles, const iMsgLevel)
{
  decl cdbs, i, adbs;
  cdbs = sizeof(asFiles);
  adbs = new array[cdbs];
  
  for (i=0;i<cdbs;i++)
    {
      adbs[i] = new Database();
      if (iMsgLevel>0) print("Loading data from ",asFiles[i],"\n");
      if (!adbs[i].Load(asFiles[i]) ) oxrunerror(sprint("Load of datafile ",asFiles[i]," failed!"));
      if (iMsgLevel>0) print(adbs[i].GetSize()," observations read, frequency: ",adbs[i].GetFrequency(),"\n");
      if (iMsgLevel>1) print("database sample: ",adbs[i].GetSample(),"\n");
    }
  if (cdbs == 1) return adbs[0];
  else return mj::DbMerge(adbs, iMsgLevel);
}