#import "packages/mj/mj"

struct Spec
{
  decl sSpecName;
  decl sDataFilePath;
  decl asExogDataFiles;

  decl cARlags;
  decl asEndoNames;
  decl aExogWSel;
  decl aCountries;

  decl fFact;
  decl iShock;
  decl s,v;
  decl sLtype;

  Info();
  Save(const sFname);
};

Spec::Info()
{
  println("sSpecName = ",sSpecName);
  println("sDataFilePath = ",sDataFilePath);
  println("asExogDataFiles = ",asExogDataFiles);
  println("cARlags = ",cARlags);
  println("asEndoNames = ",mj::as2s(asEndoNames," "));
  println("aExogWSel = ",mj::as2s(aExogWSel,","));
  for (decl c=0;c<sizeof(aCountries);c++)
    {
      println("\n",aCountries[c][0]);
      println("Z = ",mj::as2s(aCountries[c][1],","));
      println(aCountries[c][2]);
    }
  //  println("\nfFact = ",fFact);
  println("iShock = ",iShock);
  println("prior: s = ",s,", v = ",v);
  println("sLtype = ",mj::as2s(sLtype,","),"\n");
}

Spec::Save(const sFname)
{
  decl f = fopen(sFname,"w");
  fprint(f,"%v",this);
  fclose(f);
}

