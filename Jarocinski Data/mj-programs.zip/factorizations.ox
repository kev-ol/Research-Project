#include <oxfloat.h>
#import "packages/mj/mj"

FactSign4mj(const mResVar, ...);

decQR(const mA, const admQ, const admR);
FactSignmjqr23(const mResVar, ...);
FactSignmjqr34(const mResVar, ...);
FactSignmjqr45(const mResVar, ...);
FactSignmjqr(const mResVar, const dummyarg, const aDims);


FactSign4mj(const mResVar, ...)
/* identification by combination of sign restrictions and zero restrictions */
{
  decl mResVar_chol, angle_min, angle_max, angle, mResVar_sqrt;
  mResVar_chol = choleski(mResVar);
  /* Sign restriction */      
  angle_min = mResVar_chol[3][2]>0 ? -M_PI/2 : atan(mResVar_chol[3][3]/mResVar_chol[3][2]);
  angle_max = mResVar_chol[3][2]>0 ? atan(-mResVar_chol[3][2]/mResVar_chol[3][3]) : 0;
  angle = angle_min+(0+1*ranu(1,1))*(angle_max-angle_min);
  //angle = -0*M_PI;
  //angle = angle_min + asin(ranu(1,1))/M_PI_2*(angle_max-angle_min);
  mResVar_sqrt = mResVar_chol*mj::Rotation(rows(mResVar), 2, 3, angle);
  return mResVar_sqrt;
}

decQR(const mA, const admQ, const admR)
{
  decl cCols = columns(mA);
  decl mHt;
  decl ret = decqr(mA,&mHt,admR,0); 
  decl mQt = decqrmul(mHt);
  admQ[0] = mQt[0:cCols-1][]';
  return ret;
}


FactSignmjqr23(const mResVar, ...)
{
  return FactSignmjqr(mResVar,0,{<2;3>});
}

FactSignmjqr34(const mResVar, ...)
{
  return FactSignmjqr(mResVar,0,{<3;4>});
}

FactSignmjqr45(const mResVar, ...)
{
  return FactSignmjqr(mResVar,0,{<4;5>});
}

FactSignmjqr(const mResVar, const dummyarg, const aDims)
{
  decl a, mqq, mrr, toflip, mQ = unit(rows(mResVar)), mCandidate;
  decl cMaxAttempts = 100;
  decl mResVarchol = choleski(mResVar);
 
  for (a=0;a<cMaxAttempts;a++)
    {
      /* draw an orthogonal matrix */
      for (decl d=0;d<sizeof(aDims);d++)
	{
	  decQR(rann(sizerc(aDims[d]),sizerc(aDims[d])),&mqq,&mrr);
	  mQ[aDims[d]][aDims[d]] = mqq;
	}
      /* normalize shocks to be positive */
      toflip = vecindex(diagonal(mResVarchol*mQ).<0);
      mQ[][toflip] = -mQ[][toflip];
      /* check sign restrictions */
      mCandidate = mResVarchol*mQ;
      /******* test the restrictions here! ********/
      //      if (mCandidate[3][2]<0 && mCandidate[2][3]>0)  break;
      if (mCandidate[aDims[0][1]][aDims[0][0]]<0 && mCandidate[aDims[0][0]][aDims[0][1]]>0) break;
    }
  if (a == cMaxAttempts) println("sign restriction failed");
  return mCandidate;
}



FactSignmjqr_tr(const mResVar, const dummyarg)
{
  decl a, mqq, mrr, toflip, mQ = unit(rows(mResVar)), mCandidate;
  decl cMaxAttempts = 100;
  decl mResVarchol = choleski(mResVar);
  decl aDims = {<2;3;4>};
 
  for (a=0;a<cMaxAttempts;a++)
    {
      /* draw an orthogonal matrix */
      for (decl d=0;d<sizeof(aDims);d++)
	{
	  decQR(rann(sizerc(aDims[d]),sizerc(aDims[d])),&mqq,&mrr);
	  mQ[aDims[d]][aDims[d]] = mqq;
	}
      /* normalize shocks to be positive */
      toflip = vecindex(diagonal(mResVarchol*mQ).<0);
      mQ[][toflip] = -mQ[][toflip];
      /* check sign restrictions */
      mCandidate = mResVarchol*mQ;
      /******* test the restrictions here! ********/
      //      if (mCandidate[3][2]<0 && mCandidate[2][3]>0)  break;
      if (mCandidate[3][2]<0 
          && mCandidate[2][3]>0
          && mCandidate[4][2]>0) break;
    }
  if (a == cMaxAttempts) println("sign restriction failed");
  return mCandidate;
}






/*
class FactSign
{
  decl m_cMaxAttempts;
  decl m_aDims; // dimensions to rotate, array of vectors of dimension numbers
  decl m_fTest; // function which tests the restriction

  Factorize(const mResVar, ...);
};

FactSign::Setup(const aDims, const fTest, const cMaxAttempts)
{
  m_aDims = aDims;
  m_fTest = fTest;
  m_cMaxAttempts = cMaxAttempts;
}

FactSign::Factorize(const mResVar, ...)
{
  decl a, mqq, mrr, toflip, mQ = unit(rows(mResVar)), mCandidate;
  decl mResVarchol = choleski(mResVar);
 
  for (a=0;a<m_cMaxAttempts;a++)
    {
      /* draw an orthogonal matrix */
      for (decl d=0;d<sizeof(m_aDims);d++)
	{
	  decQR(rann(sizerc(m_aDims[d]),sizerc(m_aDims[d])),&mqq,&mrr);
	  mQ[m_aDims[d]][m_aDims[d]] = mqq;
	}
      /* normalize shocks to be positive */
      toflip = vecindex(diagonal(mResVarchol*mQ).<0);
      mQ[][toflip] = -mQ[][toflip];
      /* check sign restrictions */
      mCandidate = mResVarchol*mQ;
      /******* test the restrictions here! ********/
      if m_fTest(mCandidate)  break;
    }
  if (a == m_cMaxAttempts) println("sign restriction failed");
  return mCandidate;
}
*/