  
  /* Pooled, ctry variances */
  println("\n***** Pooled, country variances (p2)");
  {
    decl amZtZinv = new array[cC], amZtZinvchol = new array[cC];
    for (c=0;c<cC;c++)
      {
        amZtZinv[c] = invertsym(vars[c].mXtX()[cK:][cK:]);
        amZtZinvchol[c] = choleski(amZtZinv[c]);
      }
        
    /* starting points */
    decl amG = new array[cC], amResVar = new array[cC];
    decl mB, mMeanResVar;
    decl iChain = 1; // later loop over iChain

    for (c=0;c<cC;c++)
      {
        decl temp;
        [temp, amResVar[c]] = Arr::UnVec(amStarts[c][iChain][],{vars[c].mB(),vars[c].mUtU()});
        amG[c] = temp[cK:][];
      }
    /* mB and MeanResVar get values from the first country */
    [mB, mMeanResVar] = Arr::UnVec(amStarts[0][iChain][],{vars[0].mB(),vars[0].mUtU()});
    // truncate country specific coefs
    mB = mB[0:cK-1][];

    /* intermediate quantities for conditional posteriors */
    decl amResVarinv = new array[cC];
    decl mvar, mvarchol, part2, vcoefs, mvarinv;
    
    /* storage of results */
    decl amirf = new array[cC]; // country irfs
    decl amSumCoefs = new array[cC], amSumResVar = new array[cC]; // post.means of coefs
    decl amcres = new array[cC]; // classes for analysing residuals
    for (c=0;c<cC;c++)
      {
        amirf[c] = zeros(opt.cDraws,opt.cMAlags*cY^2);
        amSumCoefs[c] = zeros(vars[c].cX(),vars[c].cY());
        amSumResVar[c] = zeros(vars[c].cY(),vars[c].cY());
        amcres[c] = new MCResid();
        amcres[c].Initialize(vars[c].cT(),cY,opt.cDraws,1);
      }
    decl mChainInfo = zeros(opt.cDraws,2);
    decl mirf = zeros(opt.cDraws,opt.cMAlags*cY^2); // mean irfs
    decl vroots = zeros(opt.cDraws,1);
    
 
    /*************************/
    /* Gibbs sampling begins */ 
    decl actdraw, draw, iChainLength = opt.cBurnout + opt.cThin*opt.cDraws;
    println("ChainLength: ",iChainLength,"\n");
    fclose("l");
    infoinit(1000, 10);
    for (actdraw=0;actdraw<iChainLength;actdraw++)
      {         
        info(actdraw,iChainLength);
 
        
        /* draw amResVar and amG */
        for (c=0;c<cC;c++)
          {
            /* draw mResVar */
            mvar = vars[c].ResInner(mB|amG[c]);
            amResVar[c] = mj::RanIWishart( mj::Choleski(mvar), vars[c].cT() );
            amResVarinv[c] = invertsym(amResVar[c]);

            /* draw mG */
            mvar = amResVar[c]**amZtZinv[c];
            part2 = vec(vars[c].mX()[][cK:]'*(vars[c].mY() - vars[c].mX()[][:cK-1]*mB)*amResVarinv[c]);
            vcoefs = mvar*part2 + (mj::Choleski(amResVar[c])**amZtZinvchol[c])*rann(rows(mvar),1);
            amG[c] = mj::Shape(vcoefs,vars[c].cX() - cK,cY);            
          }
       
        /* draw B */
        mvarinv = 0; part2 = 0;
        for (c=0;c<cC;c++)
          {
            mvarinv += amResVarinv[c]**vars[c].mXtX()[:cK-1][:cK-1];
            part2 += vec( 
                         (vars[c].mX()[][:cK-1])'(vars[c].mY() - vars[c].mX()[][cK:]*amG[c])*amResVarinv[c]);
          }
        mvar = invertsym(mvarinv);
        mvarchol = choleski(mvar);
        if (mvarchol==0) oxrunerror("choleski failed");

        vcoefs = mvar*part2 + mvarchol*rann(rows(mvar),1);
        mB = mj::Shape(vcoefs,rows(mB),columns(mB));


        /**********************************************************/
        /* parameters drawn, now store the results of interest */
        
        if (actdraw>(opt.cBurnout-1) && imod(actdraw - opt.cBurnout + 1,opt.cThin)==0 )
          {
            draw = idiv(actdraw - opt.cBurnout + 1,opt.cThin)-1;
            
            mChainInfo[draw][0] = actdraw;
            for (c=0;c<cC;c++)
              {
                mChainInfo[draw][1] += vars[c].LogLikelihood(mB|amG[c],amResVar[c]);
              }
            
            vroots[draw][] = VARfn::MaxRoot(mB[0:cYlags-1][]);
            
            /* country irfs */
            for (c=0;c<cC;c++)
              {
                amirf[c][draw][] = var_irf(mB[0:cYlags-1][],
                                           sp_fFact(amResVar[c],mB[0:cYlags-1][]), opt.cMAlags);
              }        
            
            /* mean irf */
            decl mMeanResVar = zeros(cY,cY);
            decl cTotalT = 0;
            for (c=0;c<cC;c++)
              {
                mMeanResVar += amResVar[c]*vars[c].cT();
                cTotalT += vars[c].cT();
              }
            mirf[draw][] = var_irf(mB[0:cYlags-1][],
                                   sp_fFact(mMeanResVar/cTotalT,mB[0:cYlags-1][]), opt.cMAlags);

            /* residuals */
            for (c=0;c<cC;c++)
              {
                decl mU = (vars[c].mY() - vars[c].mX()*(mB|amG[c]))*
                  invert(sp_fFact(amResVar[c],mB[0:cYlags-1][])');
                amcres[c].StoreDraw(draw,mU);
              }
            
            /* mean coefficients and variances */
            for (c=0;c<cC;c++)
              {
                amSumCoefs[c] += (mB|amG[c]);
                amSumResVar[c] += amResVar[c];
              }
            
          } // storing results done

      } // Gibbs sampling done  
    :report_results_p2
       fopen("out/info.txt","la");
    info(actdraw,iChainLength);
  
    /****************************/
    /* report posterior results */
    print("\n",actdraw+1," draws performed, ",draw+1," draws stored\n");    
    
    /* Deviance calculation and report */
    decl Davg = double(-2*meanc(mChainInfo[][1]));
    decl pV = double(0.5*varc(mChainInfo[][1]));
    decl Dhat = 0;
    for (c=0;c<cC;c++)
      Dhat += -2*vars[c].LogLikelihood(amSumCoefs[c]/opt.cDraws,amSumResVar[c]/opt.cDraws);
    decl pD = Davg - Dhat;
    decl DIC = Davg + pD; 
    mDICreport[2][] = Davg~pD~DIC;
 
    print("Mean Post. Deviance: ",Davg,", pV: ","%.2f", pV, ", pD: ", "%.2f", pD, ", DIC: ", DIC,"\n");   
    
    print("Deviance report","%r",{"bu","po","p2"},"%c",{"Davg","pD","DIC"},mDICreport);

    /* save chain info */
    savemat("out/chaininfo.fmt",mChainInfo);

    /* country irfs */
    for (c=0;c<cC;c++)
      {
        mtoplot = quantilec(amirf[c], opt.vQuant);
        DrawIRFs(c*cY, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]},
                 sp.asEndoNames, -1, sp.iShock,"out/irf-p2-"~sp.aCountries[c][0]~"-");
      }    
    SaveDrawWindow("out/irfs-p2.eps");
    CloseDrawWindow();
    
    /* mean irfs */
    mtoplot = quantilec(mirf, opt.vQuant);
    DrawIRFs(0, {mtoplot[0][],mtoplot[1:2][],mtoplot[3:4][]}, sp.asEndoNames, -1, sp.iShock,"out/irf-p2-mean-");
    SaveDrawWindow("out/irfs-p2-mean.eps");
    CloseDrawWindow(); 
    /* save the whole distribution of mean responses */
    savemat(sprint("out/irf-p2-mean.fmt"),mirf);
    
    /* report on sacrifice ratio */
    ReportSacrifice(mirf,0,1,sp.iShock,cY,opt.cMAlags-1,"out/sacrifice-p2");
    ReportSacrifice(mirf,0,1,sp.iShock,cY,23,"out/sacrifice-p2");

    /* residuals */
    for (c=0;c<cC;c++)
      {
        amcres[c].Report("out/err-p2-"~sp.aCountries[c][0],vars[c]);
      }
            
  } // Pooled (ctry variances) done