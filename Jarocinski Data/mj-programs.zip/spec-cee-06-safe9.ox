{
  sp.sSpecName = "spec-cee-06-safe9";

  /* set data specification */
  sp.sDataFilePath = "../data/2008-cee/";
  sp.asExogDataFiles = {"../data/2008-world/world1"~EXT,"../data/2008-world/dummies"~EXT};

  sp.cARlags = 6;
  sp.asEndoNames = { "lnipsa", "lncpi", "r-mkt", "lneur" };
  sp.aExogWSel = aWorld~aUS;

  decl aExogZSel = {"Constant",0,0}~aGer;
  decl sSampleEnd = "-1(-1)";

  sp.aCountries = {};
  sp.aCountries |= {{"czech",aExogZSel,"1999(7) - "~sSampleEnd}};
  sp.aCountries |= {{"hungary",aExogZSel~{"d9601",0,2,"d9808",0,6,"d0302",0,5,"d0605",0,4},
                                                                "1995(4) - "~sSampleEnd}};
  sp.aCountries |= {{"poland",aExogZSel~{"d9808",0,6,"d0107",0,3}, "1995(6) - "~sSampleEnd}};
  sp.aCountries |= {{"slovenia",aExogZSel,"1997(5) - "~sSampleEnd}};
 

  /* set factorization */
  sp_fFact = FactSignmjqr23;
  sp.iShock = strfind(sp.asEndoNames,"r-mkt");
  
  /* set prior */
  sp.s = 0; sp.v = -1;

  sp.sLtype = "m1";
}  

  

